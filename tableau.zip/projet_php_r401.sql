-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : ven. 31 mars 2023 à 21:42
-- Version du serveur : 5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet_php_r401`
--

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

DROP TABLE IF EXISTS `article`;
CREATE TABLE IF NOT EXISTS `article` (
  `Id_article` int(11) NOT NULL,
  `Titre` varchar(50) COLLATE utf8_bin NOT NULL,
  `Description` varchar(200) COLLATE utf8_bin NOT NULL,
  `Auteur` varchar(30) COLLATE utf8_bin NOT NULL,
  `date_de_publication` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Nb_likes` int(11) DEFAULT '0',
  `Nb_dislikes` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id_article`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`Id_article`, `Titre`, `Description`, `Auteur`, `date_de_publication`, `Nb_likes`, `Nb_dislikes`) VALUES
(1, 'La crise', 'C\'est la crise en France entre les grèves et les manif au cause des réformes et l\'inflation c\'est le bordel.', 'Moi', '2023-03-30 00:11:12', 53, 0),
(141, 'mw2 citation', 'bravo six. Silence radio', 'Capitaine Price', '2023-03-31 13:12:19', 48, 0),
(110, 'mw2 citation', 'Nous avanÃ§on tel un souffe exalÃ© de la Terre. La rage au coeur et dans un but unique. Nous... alons... Le tuer.', 'Capitaine Price', '2023-03-31 13:12:58', 48, 0);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `Identifiant` varchar(20) COLLATE utf8_bin NOT NULL,
  `Mdp` varchar(20) COLLATE utf8_bin NOT NULL,
  `role` varchar(20) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`Identifiant`, `Mdp`, `role`) VALUES
('Flomouk2', '20082003', 'moderator'),
('Prof1', '00001111', 'moderator'),
('Prof2', '0000', 'publisher'),
('Watcher1', '6666', 'publisher'),
('bravo6', '141', 'moderator');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

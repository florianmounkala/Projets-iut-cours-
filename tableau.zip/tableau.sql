declare
    requete clob;
    var_group_by clob;
    x_group_by clob;
    date_limite clob;
    date_c clob ;
    total_courriers number;
    year_v clob;
    nb_courrier date ;
    statut_converti varchar(4000);
    statut_nt_converti varchar(4000);
    service_converti varchar(3500);
    x varchar(4000);
    y varchar(4000);
    z varchar(3500);
    statut_ntz varchar(120);
    test_total_courrier varchar(4000);
    z_values sys.odcivarchar2list := sys.odcivarchar2list();
begin
    --Choix filtres 
    if :P1_VALEUR_FILTRE_ANNEE_TRAITEMENT IS not null then
        year_v := 'and nvl(C_ANNEEE_DE_VALIDATION_NB, 999)= DECODE('''||:P1_VALEUR_FILTRE_ANNEE_TRAITEMENT || ''', ''0'' ,C_ANNEEE_DE_VALIDATION_NB, null ,C_ANNEEE_DE_VALIDATION_NB ,'''|| :P1_VALEUR_FILTRE_ANNEE_TRAITEMENT || ''')';
    else 
        year_v := '';
    end if ;

    if :P1_VALEUR_CHOIX_DATE_FORMAT = '1' AND :P1_VALEUR_DT_VAR_DEBUT IS NOT NULL AND :P1_VALEUR_DT_VAR_FIN IS NOT NULL then
         date_c := 'AND TO_DATE(TO_CHAR(C_DT,''YYYY-MM-DD''), ''YYYY-MM-DD'') BETWEEN TO_DATE('''||:P1_VALEUR_DT_VAR_DEBUT|| ''', ''YYYY-MM-DD'') AND TO_DATE('''||:P1_VALEUR_DT_VAR_FIN || ''', ''YYYY-MM-DD'') ' ; 
    elsif :P1_VALEUR_CHOIX_DATE_FORMAT = '2' and :P1_VALEUR_DT_FIXE IS NOT NULL  then
        date_c := 'AND TO_DATE(TO_CHAR(C_DT,''YYYY-MM-DD''), ''YYYY-MM-DD'') = TO_DATE('''||:P1_VALEUR_DT_FIXE || ''', ''YYYY-MM-DD'')'  ;
    else 
        date_c := ' ' ;
    end if ;


    if :P1_VALEUR_CHOIX_DATELIMITE_FORMAT = '2' and :P1_DT_VALEUR_LIMITE_FIXE IS NOT NULL then
        date_limite := 'AND TO_DATE(TO_CHAR(C_LIMITE_DT,''YYYY-MM-DD''), ''YYYY-MM-DD'') = TO_DATE('''||:P1_DT_VALEUR_LIMITE_FIXE || ''', ''YYYY-MM-DD'')'; 
    elsif :P1_VALEUR_CHOIX_DATELIMITE_FORMAT = '1' and :P1_VALEUR_DT_LIMITE_VAR_DEBUT IS NOT NULL and :P1_VALEUR_DT_LIMITE_VAR_FIN IS NOT NULL then
        date_limite := 'AND TO_DATE(TO_CHAR(C_LIMITE_DT,''YYYY-MM-DD''), ''YYYY-MM-DD'') BETWEEN TO_DATE('''||:P1_VALEUR_DT_LIMITE_VAR_DEBUT || ''', ''YYYY-MM-DD'') AND TO_DATE('''||:P1_VALEUR_DT_LIMITE_VAR_FIN|| ''',''YYYY-MM-DD'') ';
    else 
        date_limite := ' ';
    end if ;

    if :P1_VALEUR_FILTRE_STATUT is not null then
        y := '$'|| :P1_VALEUR_FILTRE_STATUT ||'$';
        y := REPLACE(y, ':', '2,4');
        y := REPLACE(y, '2', '''');
        y := REPLACE(y, '4', '''');
        y := REPLACE(y, '$', '''');
        statut_converti :=' and ZTYSTA_CDA in ('||y||') ';
    else 
        statut_converti := ''; 
    end if;

    if :P1_SEL_CAT is not null then
        z := :P1_SEL_CAT;
        z := REPLACE(z, ':', ',');
        service_converti := 'and C_DESTINATION_LB in (select regexp_substr('''|| z ||''',''[^,]+'', 1, level) from dual connect by regexp_substr('''|| z ||''', ''[^,]+'', 1, level) is not null)';
    else 
        service_converti := ''; 
        z := 'DGA';
    end if;
    
   if :P1_VALEUR_FILTRE_STATUT_NT is not null then
        x := '$'||:P1_VALEUR_FILTRE_STATUT_NT || '$' ;
        x := REPLACE(x, ':', '2,4');
        x := REPLACE(x, '2', '''');
        x := REPLACE(x, '4', '''');
        x := REPLACE(x, '$', '''');
        statut_nt_converti :=' and ZTYSTA_CDA in ('||x||') ';
        statut_ntz :='';
    else 
        x := '$EAVIS:VALDGA:VAL:ATT:COU:NEW$';
        x := REPLACE(x, ':', '2,4');
        x := REPLACE(x, '2', '''');
        x := REPLACE(x, '4', '''');
        x := REPLACE(x, '$', '''');
        statut_ntz := ' AND ZTYSTA_CDA in ('||x||')';
        statut_nt_converti :=' ';
    end if;

    case :P1_VALEUR_FILTRE_GROUP_BY
        when  '1' then
            var_group_by := 'ZTYSTA_CDA  as FILTRE,';
            x_group_by := 'GROUP BY ZTYSTA_CDA';
        when  '2' then
            var_group_by :=  'C_DESTINATION_LB as FILTRE,';
            x_group_by := 'GROUP BY C_DESTINATION_LB ';
        when  '3' then
            var_group_by := ' C_SOURCE_LB as FILTRE , ';
            x_group_by := 'GROUP BY C_SOURCE_LB';
        when  '4' then
            var_group_by := ' C_ANNEEE_DE_VALIDATION_NB as FILTRE, ';
            x_group_by := 'GROUP BY C_ANNEEE_DE_VALIDATION_NB ';
        when  '5' then
            var_group_by := 'C_CONFIDENTIALITE_ON as FILTRE, ';
            x_group_by := 'GROUP BY C_CONFIDENTIALITE_ON ';
        when  '6' then
            var_group_by := 'C_LVL_URG_NB as FILTRE, ';
            x_group_by := 'GROUP BY C_LVL_URG_NB ';
        when  '7' then
            var_group_by := 'ZTYDOC_CDA as FILTRE, '; 
            x_group_by :='GROUP BY ZTYDOC_CDA ';
        when  '8' then
            var_group_by := 'C_DT as FILTRE, ';
            x_group_by := 'GROUP BY C_DT ';
        when  '9' then
            var_group_by := ' C_LIMITE_DT as FILTRE, ';
            x_group_by := 'GROUP BY C_LIMITE_DT ';
        else 
            var_group_by := ' ''total'' as FILTRE,';
            x_group_by := ' ';
    end case;

    if :P1_VALEUR_FILTRE_COURRIER= 'Non' then
        test_total_courrier := 'SELECT count(*) FROM MSTAT65.COURRIERS 
            where nvl(C_CONFIDENTIALITE_ON , 0) = DECODE('''|| :P1_VALEUR_FILTRE_CONFIDENTIALITE || ''', ''O'' , ''Oui'', ''N'' , ''Non'' ,nvl(C_CONFIDENTIALITE_ON , 0))
            '||year_v||'
            and ZTYDOC_CDA= DECODE('''|| :P1_VALEUR_FILTRE_DOCTYPE || ''', ''TOUS'' ,ZTYDOC_CDA , null  ,ZTYDOC_CDA , '''|| :P1_VALEUR_FILTRE_DOCTYPE || ''')
            '||service_converti ||'
            '|| date_limite ||'
            '||statut_converti ||' 
            '|| date_c ||'
            and C_LVL_URG_NB = DECODE('''||:P1_VALEUR_FILTRE_LVL_URGENCE || ''', null ,C_LVL_URG_NB ,''999'',C_LVL_URG_NB, '''|| :P1_VALEUR_FILTRE_LVL_URGENCE || ''') ';
        EXECUTE IMMEDIATE test_total_courrier INTO total_courriers ;
        if total_courriers is null or total_courriers = 0 then 
            total_courriers :=1 ;
        end if ;
        requete :=  'SELECT '|| var_group_by || 'count(*) as Nb_Courriers , ROUND(((count(*) * 100)/ '|| total_courriers ||'), 2) as Pourcentage
            FROM MSTAT65.COURRIERS 
            where nvl(C_CONFIDENTIALITE_ON , 0) = DECODE('''|| :P1_VALEUR_FILTRE_CONFIDENTIALITE || ''', ''O'' , ''Oui'', ''N'' , ''Non'' ,nvl(C_CONFIDENTIALITE_ON , 0))
            '||year_v||'
            and ZTYDOC_CDA= DECODE('''|| :P1_VALEUR_FILTRE_DOCTYPE || ''', ''TOUS'' ,ZTYDOC_CDA , null  ,ZTYDOC_CDA , '''|| :P1_VALEUR_FILTRE_DOCTYPE || ''')
            '||service_converti ||'
            '|| date_limite ||'
            '||statut_converti ||' 
            '|| date_c ||'
            and C_LVL_URG_NB = DECODE('''||:P1_VALEUR_FILTRE_LVL_URGENCE || ''', null ,C_LVL_URG_NB ,''999'',C_LVL_URG_NB, '''|| :P1_VALEUR_FILTRE_LVL_URGENCE || ''') '||x_group_by || ' ;';
    else 
        test_total_courrier := 'SELECT count(*) FROM MSTAT65.COURRIERS 
            where nvl(C_CONFIDENTIALITE_ON , 0) = DECODE('''|| :P1_VALEUR_FILTRE_CONFIDENTIALITE || ''', ''O'' , ''Oui'', ''N'' , ''Non'' ,nvl(C_CONFIDENTIALITE_ON , 0))
            '||year_v||'
            and ZTYDOC_CDA= DECODE('''|| :P1_VALEUR_FILTRE_DOCTYPE || ''', ''TOUS'' ,ZTYDOC_CDA , null  ,ZTYDOC_CDA , '''|| :P1_VALEUR_FILTRE_DOCTYPE || ''')
            '||service_converti ||'
            '|| date_limite ||'
            '||statut_nt_converti ||' 
            '|| date_c ||'
            '||statut_ntz||'
            and C_LIMITE_DT - C_DT > 30
            and C_LVL_URG_NB = DECODE('''||:P1_VALEUR_FILTRE_LVL_URGENCE || ''', null ,C_LVL_URG_NB ,''999'',C_LVL_URG_NB, '''|| :P1_VALEUR_FILTRE_LVL_URGENCE || ''') ';
            
        EXECUTE IMMEDIATE test_total_courrier INTO total_courriers ; 
        if total_courriers is null or total_courriers = 0 then 
            total_courriers :=1 ;
        end if ;
        requete := 'SELECT '|| var_group_by || ' count(*) as Nb_Courriers , ROUND(((count(*) * 100)/ '|| total_courriers ||'), 2) as Pourcentage
            FROM (     
            SELECT *
            FROM MSTAT65.COURRIERS 
            where nvl(C_CONFIDENTIALITE_ON , 0) = DECODE('''|| :P1_VALEUR_FILTRE_CONFIDENTIALITE || ''', ''O'' , ''Oui'', ''N'' , ''Non'' ,nvl(C_CONFIDENTIALITE_ON , 0))
            '||year_v||'
            and ZTYDOC_CDA= DECODE('''||:P1_VALEUR_FILTRE_DOCTYPE || ''', ''TOUS'' ,ZTYDOC_CDA , null  ,ZTYDOC_CDA , '''|| :P1_VALEUR_FILTRE_DOCTYPE || ''')
            and C_LVL_URG_NB = DECODE('''||:P1_VALEUR_FILTRE_LVL_URGENCE || ''', null ,C_LVL_URG_NB ,''999'',C_LVL_URG_NB, '''|| :P1_VALEUR_FILTRE_LVL_URGENCE || ''')
            '|| date_limite ||' 
            '||service_converti ||'
            '|| date_c ||'
            '||statut_nt_converti ||'
            INTERSECT Select * from MSTAT65.courriers
                where C_LIMITE_DT - C_DT > 30
                AND ZTYSTA_CDA in (''EAVIS'' , ''VALDGA'' , ''VAL'' , ''ATT'' , ''COU'' , ''NEW'') ) ' ||x_group_by || ' ;';
    end if ;

    /*APEX_MAIL.SEND(
    p_to        => 'florian.mounkala@ha-py.fr',
    p_from      => 'flomrian24@gmail.com',
    p_subj      => 'Test requete',
    p_body      => requete
    );*/
        
    return requete;
end;

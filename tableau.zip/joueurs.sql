-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 31 jan. 2023 à 16:19
-- Version du serveur : 5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `equipe-foot`
--

-- --------------------------------------------------------

--
-- Structure de la table `joueurs`
--

DROP TABLE IF EXISTS `joueurs`;
CREATE TABLE IF NOT EXISTS `joueurs` (
  `numero_de_licence` int(11) NOT NULL,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(50) DEFAULT NULL,
  `DateDeNaissance` date DEFAULT NULL,
  `photo` varchar(50) DEFAULT NULL,
  `taille` decimal(15,2) DEFAULT NULL,
  `poste_favori` varchar(50) DEFAULT NULL,
  `poids` decimal(15,2) DEFAULT NULL,
  `Statut` varchar(50) DEFAULT NULL,
  `notes_personnelles` varchar(50) DEFAULT NULL,
  `Id_Rencontre` int(11) NOT NULL,
  PRIMARY KEY (`numero_de_licence`),
  KEY `Id_Rencontre` (`Id_Rencontre`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `joueurs`
--

INSERT INTO `joueurs` (`numero_de_licence`, `nom`, `prenom`, `DateDeNaissance`, `photo`, `taille`, `poste_favori`, `poids`, `Statut`, `notes_personnelles`, `Id_Rencontre`) VALUES
(1, 'Kylian', 'Mbappé', '2002-09-03', 'xuxxx.img', '1.75', 'Attaquant', '75.00', 'Attaquant', NULL, 1),
(2, 'Olivier', 'Giroud', '2003-01-21', 'mdr.img', '1.80', 'Milieu', '85.00', 'Milieu', NULL, 1),
(3, 'Antoine', 'Griezman', '2004-01-13', 'mdr', '1.87', 'Milieu', NULL, 'Ataquant/ defenseur/ mileu', NULL, 1),
(4, 'Paul', 'Pogba', '1995-01-10', 'xuxxx.img', '1.90', 'Attaquant', '85.00', 'Attaquant', NULL, 1),
(5, 'Karim', 'Benzema', '2000-01-19', 'mdr.PNG', '1.77', 'Milieu', '87.00', 'Ataquant/ defenseur/ mileu', NULL, 1),
(6, 'Raphael', 'Varane', '1999-01-12', 'lol.png', '1.89', 'Attaquant', '77.00', 'Attaquant', NULL, 1),
(7, 'Hugo', 'Lloris', '1999-01-14', 'ohayo.img', '1.85', 'Goal', '80.00', 'Goal', NULL, 1),
(8, 'Presnel', 'Kipembé', '1994-08-17', 'ptdr.img', '1.90', 'Defenseur', '80.00', 'Defenseur', NULL, 1),
(9, 'N\'Golo', 'Kanté', '1997-02-12', 'victoire.img', '1.78', 'milieu', '83.00', 'milieu/defenseur', NULL, 1),
(10, 'Lucas', 'Digne', '1997-01-13', 'mdr.img', '1.86', 'Défenseur', '70.00', 'Défenseur', NULL, 1),
(11, 'Lucas', 'Hernendez', '2003-01-08', 'yyy.img', '1.85', 'Defenseur', '80.00', 'Defenseur', NULL, 1),
(12, 'Marcus', 'Thuram', '1996-01-10', 'vilbrequin.img', '2.00', 'Attaquant', '90.00', 'Attaquant', NULL, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

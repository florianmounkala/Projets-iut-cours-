-- creation de toutes les tables

CREATE TABLE SAE_Equipement(
   id_equipement NUMBER(10),
   date_derni�re_r�vision DATE,
   nom VARCHAR2(50) ,
   date_de_validit�_r�vision DATE,
   PRIMARY KEY(id_equipement)
);

CREATE TABLE SAE_Locataire(
   id_locataire NUMBER(10),
   nom VARCHAR2(50) ,
   prenom VARCHAR2(50) ,
   adresse_domicil_soci�t� VARCHAR2(150) ,
   E_mail VARCHAR2(50) ,
   T�l CHAR(10) ,
   Qualit� VARCHAR2(50) ,
   PRIMARY KEY(id_locataire)
);

CREATE TABLE SAE_Batiment(
   n_batiment NUMBER(3),
   nb_logement NUMBER(10),
   code_postal CHAR(5) ,
   nb_�tage VARCHAR2(50) ,
   rue VARCHAR2(100) ,
   ville VARCHAR2(50) ,
   PRIMARY KEY(n_batiment)
);
drop table sae_charges cascade constraint;
CREATE TABLE SAE_Charges(
   r�f VARCHAR2(10) ,
   consommation decimal(10,2),
   unit� varchar2(5),
   TypeCharges VARCHAR2(50) ,
   Prix_unitaire decimal(19,4),
   Abonnement decimal(19,4),
   PRIMARY KEY(r�f)
);

CREATE TABLE SAE_Entreprise(
   n_SIREN CHAR(9) ,
   Nom VARCHAR2(50) ,
   Adresse VARCHAR2(50) ,
   CP VARCHAR2(50) ,
   IBAN VARCHAR2(50) ,
   adresse_mail VARCHAR2(50) ,
   T�l CHAR(10) ,
   PRIMARY KEY(n_SIREN)
);

CREATE TABLE SAE_Type_facture(
   Id_Type_facture NUMBER(10),
   typeF VARCHAR2(50) ,
   PRIMARY KEY(Id_Type_facture)
);

CREATE TABLE SAE_Logement(
   n_batiment NUMBER(3),
   n_logement NUMBER(10),
   localisation CLOB,
   typeLogement VARCHAR2(50) ,
   r�gime_juridique VARCHAR2(50) ,
   balcon NUMBER(1),
   p�riode_de_construction DATE,
   surface NUMBER(6,2)  ,
   nb_pi�ces NUMBER(10),
   garage NUMBER(1),
   jardin NUMBER(1),
   �tage_ VARCHAR2(50) ,
   porte_ VARCHAR2(50) ,
   r�f_EDL NUMBER(10),
   Base_loyer_M_ NUMBER(19,4),
   ICC NUMBER(3),
   charges_fixes NUMBER(19,4),
   PRIMARY KEY(n_batiment, n_logement),
   FOREIGN KEY(n_batiment) REFERENCES SAE_Batiment(n_batiment)
);

CREATE TABLE SAE_Facture(
   r�f�rence CHAR(10) ,
   r�f�rence_du_paiement VARCHAR2(50) ,
   date_facture DATE,
   charges_dues NUMBER(6,2)  ,
   charges_r�gularis�s NUMBER(6,2)  ,
   Date_de_paiement DATE,
   type_de_paiement VARCHAR2(50) ,
   aide NUMBER(1),
   montant_de_l_aide NUMBER(10),
   Prix NUMBER(19,4),
   Id_Type_facture NUMBER(10) NOT NULL,
   n_SIREN CHAR(9)  NOT NULL,
   PRIMARY KEY(r�f�rence),
   FOREIGN KEY(Id_Type_facture) REFERENCES SAE_Type_facture(Id_Type_facture),
   FOREIGN KEY(n_SIREN) REFERENCES SAE_Entreprise(n_SIREN)
);

CREATE TABLE SAE_Fiche_diagnostic(
   R�f VARCHAR2(50) ,
   Amiante NUMBER(1),
   Date_Amiante DATE,
   Plomb NUMBER(1),
   Date_plomb DATE,
   date_diag_ERP DATE,
   Date_ERP_de_validit� DATE,
   Date_limite_validit�_DPE DATE,
   Date_diag_DPE DATE,
   n_batiment NUMBER(3) NOT NULL,
   n_logement NUMBER(10) NOT NULL,
   PRIMARY KEY(R�f),
   FOREIGN KEY(n_batiment, n_logement) REFERENCES SAE_Logement(n_batiment, n_logement)
);

CREATE TABLE SAE_Contrat_bail(
   id_bail NUMBER(10),
   date_d�but DATE,
   date_fin DATE,
   frais_d_agence NUMBER(19,4),
   Caution NUMBER(19,4),
   nb_locataire NUMBER(10),
   n_batiment NUMBER(3) NOT NULL,
   n_logement NUMBER(10) NOT NULL,
   PRIMARY KEY(id_bail),
   FOREIGN KEY(n_batiment, n_logement) REFERENCES SAE_Logement(n_batiment, n_logement)
);

CREATE TABLE SAE_signer(
   id_bail NUMBER(10),
   id_locataire NUMBER(10),
   PRIMARY KEY(id_bail, id_locataire),
   FOREIGN KEY(id_bail) REFERENCES SAE_Contrat_bail(id_bail),
   FOREIGN KEY(id_locataire) REFERENCES SAE_Locataire(id_locataire)
);

CREATE TABLE SAE_Posseder_(
   id_equipement NUMBER(10),
   n_batiment NUMBER(3),
   n_logement NUMBER(10),
   PRIMARY KEY(id_equipement, n_batiment, n_logement),
   FOREIGN KEY(id_equipement) REFERENCES SAE_Equipement(id_equipement),
   FOREIGN KEY(n_batiment, n_logement) REFERENCES SAE_Logement(n_batiment, n_logement)
);

CREATE TABLE SAE_lier(
   r�f�rence CHAR(10) ,
   n_batiment NUMBER(3),
   PRIMARY KEY(r�f�rence, n_batiment),
   FOREIGN KEY(r�f�rence) REFERENCES SAE_Facture(r�f�rence),
   FOREIGN KEY(n_batiment) REFERENCES SAE_Batiment(n_batiment)
);

CREATE TABLE SAE_associer(
   n_batiment NUMBER(3),
   n_logement NUMBER(10),
   r�f VARCHAR2(10) ,
   quotit� VARCHAR2(50) ,
   PRIMARY KEY(n_batiment, n_logement, r�f),
   FOREIGN KEY(n_batiment, n_logement) REFERENCES SAE_Logement(n_batiment, n_logement),
   FOREIGN KEY(r�f) REFERENCES SAE_Charges(r�f)
);

CREATE TABLE SAE_correspondre(
   r�f�rence CHAR(10) ,
   r�f VARCHAR2(10) ,
   Paiement NUMBER(11,2)  ,
   PRIMARY KEY(r�f�rence, r�f),
   FOREIGN KEY(r�f�rence) REFERENCES SAE_Facture(r�f�rence),
   FOREIGN KEY(r�f) REFERENCES SAE_Charges(r�f)
);

-- insertion des donn�es locataires
 
insert into SAE_Locataire(id_locataire, nom, prenom, adresse_domicil_soci�t�, E_mail, T�l, Qualit�) values (0, 'R�becca', 'Armand', '7 rue des Fleurs 75012 Paris', 'RebeccaArmand@gmail.com', '0695454332', 'jsp1'); 
insert into SAE_Locataire(id_locataire, nom, prenom, adresse_domicil_soci�t�, E_mail, T�l, Qualit�) values (1, 'Pierre', 'Giraud', '9 avenue des boulevards 75014 Paris', 'PierreGiraud@gmail.com', '0693504332', 'jsp2'); 
insert into SAE_Locataire(id_locataire, nom, prenom, adresse_domicil_soci�t�, E_mail, T�l, Qualit�) values (2, 'Mathilde', 'Mayet', '342 route de fosse 75011 Paris', 'MathildeMayet@gmail.com', '07657463', 'jsp3') ;
insert into SAE_Locataire(id_locataire, nom, prenom, adresse_domicil_soci�t�, E_mail, T�l, Qualit�) values (3, 'Florian', 'Deschamps', '7 rue des Fleurs 75012 Paris', 'FlorianDeschamps@gmail.com', '0695342321', 'jsp4') ;
insert into SAE_Locataire(id_locataire, nom, prenom, adresse_domicil_soci�t�, E_mail, T�l, Qualit�) values (4, 'Thomas', 'Bouisse', '343 route de fosse 75011 Paris', 'ThomasBouisse@gmail.com', '0798562412', 'jsp5') ;

-- insertion des donn�es contrat_bail

insert into sae_contrat_bail(id_bail, date_d�but, date_fin, frais_d_agence, caution, nb_locataire, n_batiment, n_logement) values (0, '12/01/2022', '12/01/2024', '100', '400', '1', '1', '1');

-- insertion des donn�es batiment

insert into sae_batiment(n_batiment, nb_logement, code_postal, nb_�tage, rue, ville) values (0, 20, '75012', '4', 'rue des Fleurs', 'Paris');
insert into sae_batiment(n_batiment, nb_logement, code_postal, nb_�tage, rue, ville) values (1, 15, '75014', '3', 'avenue des boulevards', 'Paris');
insert into sae_batiment(n_batiment, nb_logement, code_postal, nb_�tage, rue, ville) values (2, 25, '75011', '5', 'route de fosse', 'Paris');

-- insertion des donn�es logement

insert into sae_logement(n_batiment, n_logement, localisation, typelogement, r�gime_juridique, balcon, p�riode_de_construction, surface, nb_pi�ces, garage, jardin, �tage_, porte_, r�f_edl, base_loyer_m_, icc, charges_fixes) values (0, 0, '7 rue des Fleurs 75012 Paris', 'appartement', 'connais pas les types de r�gime juridique', 1, '12/02/2009', 40, 5, 0, 0, '1er �tage', '7', 10102020, 600, 200, 100);
insert into sae_logement(n_batiment, n_logement, localisation, typelogement, r�gime_juridique, balcon, p�riode_de_construction, surface, nb_pi�ces, garage, jardin, �tage_, porte_, r�f_edl, base_loyer_m_, icc, charges_fixes) values (1, 1, '9 avenue des boulevards 75014 Paris', 'appartement', 'connais pas les types de r�gime juridique', 1, '12/02/2011', 20, 3, 0, 0, '2�me �tage', '9', 10103030, 400, 200, 70);
insert into sae_logement(n_batiment, n_logement, localisation, typelogement, r�gime_juridique, balcon, p�riode_de_construction, surface, nb_pi�ces, garage, jardin, �tage_, porte_, r�f_edl, base_loyer_m_, icc, charges_fixes) values (2, 2, '342 route de fosse 75011 Paris', 'appartement', 'connais pas les types de r�gime juridique', 1, '12/02/2006', 60, 5, 0, 0, '5�me �tage', '20', 10104040, 900, 200, 200);

-- insertion des donn�es dans la facture

insert into sae_facture(r�f�rence, R�F�RENCE_DU_PAIEMENT, DATE_FACTURE, CHARGES_DUES, CHARGES_R�GULARIS�S, DATE_DE_PAIEMENT, TYPE_DE_PAIEMENT, AIDE, MONTANT_DE_L_AIDE, PRIX, ID_TYPE_FACTURE, N_SIREN) values (0, '80KM0', '12/11/2022', 40, 0, '02/11/2022', 'Virement', 0, 0, 50, 1, 0);
insert into sae_facture(r�f�rence, R�F�RENCE_DU_PAIEMENT, DATE_FACTURE, CHARGES_DUES, CHARGES_R�GULARIS�S, DATE_DE_PAIEMENT, TYPE_DE_PAIEMENT, AIDE, MONTANT_DE_L_AIDE, PRIX, ID_TYPE_FACTURE, N_SIREN) values (1, '615XJ', '13/11/2022', 50, 0, '02/11/2022', 'Virement', 0, 0, 60, 1, 0);
insert into sae_facture(r�f�rence, R�F�RENCE_DU_PAIEMENT, DATE_FACTURE, CHARGES_DUES, CHARGES_R�GULARIS�S, DATE_DE_PAIEMENT, TYPE_DE_PAIEMENT, AIDE, MONTANT_DE_L_AIDE, PRIX, ID_TYPE_FACTURE, N_SIREN) values (2, 'Y4P75', '01/11/2022', 100, 0, '24/10/2022', 'Virement', 0, 0, 1000, 2, 243564567);

-- insertion des donn�es dans entreprise

insert into sae_entreprise(n_siren, nom, adresse, cp, iban, adresse_mail, t�l)values (362521879, 'New Tech', '210 avenue de Rangueil', 75010, 'FR7630001007941234567890185', 'NewTech@gmail.com', 0598123445);
insert into sae_entreprise(n_siren, nom, adresse, cp, iban, adresse_mail, t�l)values (243564567, 'Les charpentiers', 'Rue de la paix', 78012, 'FR7630004000031234567890143', 'LesCharpentiers@gmail.com', 0596043405);
insert into sae_entreprise(n_siren, nom, adresse, cp, iban, adresse_mail, t�l)values (453123765, 'Entreprise travaux', 'Rue de la guerre', 77012, 'FR7630006000011234567890189', 'Travaux@gmail.com', 0598032345);
insert into sae_entreprise(n_siren, nom, adresse, cp, iban, adresse_mail, t�l)values (0, null, null, null, null, null, null);
-- insertion dans type facture

insert into sae_type_facture(id_type_facture, typeF) values (1, 'Quittance de Loyer');
insert into sae_type_facture(id_type_facture, typeF) values (2, 'Facture des travaux');

-- insertion dans fiche diagnostic

insert into sae_fiche_diagnostic(r�f, amiante, date_amiante, plomb, date_plomb, date_diag_erp, date_erp_de_validit�, DATE_LIMITE_VALIDIT�_DPE, date_diag_dpe, n_batiment, n_logement) values (101010100, 0, '03/03/2018', 0, '28/09/2017', '14/02/2019', '10/02/2026', '19/12/2026', '19/12/2019', 0, 0);

-- insertion dans �quipement 

insert into sae_equipement (id_equipement, date_derni�re_r�vision, nom, date_de_validit�_r�vision) values (0, '14/03/2015', 'Chaudi�re', '14/03/2025');

--insertion dans charges

insert into sae_charges(r�f, consommation, unit�, TypeCharges, prix_unitaire, abonnement) values ('ELEC10001', 10, 'Kwh', 'Electricit�', '1,34', 30);
insert into sae_charges(r�f, consommation, unit�, TypeCharges, prix_unitaire, abonnement) values ('EAU10001', 40, 'm3', 'Eau', '4,14', 60);

-- affichage des donn�es de chaque table

select * from sae_Locataire;
select * from sae_batiment;
select * from sae_logement;
select * from sae_facture;
select * from sae_type_facture;
select * from sae_entreprise;
select * from sae_charges;
select * from sae_contrat_bail;
select * from sae_fiche_diagnostic;
select * from sae_equipement;

-- fonction 1 : renvoyer le loyer d'un locataire donn� 



commit;
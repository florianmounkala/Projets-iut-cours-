package modele;
import java.util.Collection;

import java.util.HashSet;
import java.util.Objects;

public class Creneau {
	
	private String jourc;
	private String debsemc;
	private String heuredc;
	private String typec;
	private String heurefc;
	private Collection<Enseignant> id_enseign;
	private Collection<Enseignant> Ensc;
	private Collection<Salle> SalC;
    private Mat matc;
    private Groupe grpc;
    private Collection<Salle> nsalle;
	
	public Creneau(String jourc, String debsemc, String heuredc, String typec, String heurefc, Mat mat, Groupe grpc) {
		this.jourc = jourc;
		this.debsemc = debsemc;
		this.heuredc = heuredc;
		this.id_enseign = new HashSet<>();
		this.grpc = grpc;
		this.matc = mat;
		this.nsalle = new HashSet<>();
		this.setEnsc(new HashSet<>());
		this.SalC = new HashSet<>();
	}
	
	
	
	public Collection<Enseignant> getId_enseign() {
		return id_enseign;
	}



	public void setId_enseign(Collection<Enseignant> id_enseign) {
		this.id_enseign = id_enseign;
	}



	public Mat getMatc() {
		return matc;
	}



	public void setMatc(Mat matc) {
		this.matc = matc;
	}



	public Groupe getGrpc() {
		return grpc;
	}



	public void setGrpc(Groupe grpc) {
		this.grpc = grpc;
	}



	public Collection<Salle> getNsalle() {
		return nsalle;
	}



	public void setNsalle(Collection<Salle> nsalle) {
		this.nsalle = nsalle;
	}



	public String getJourc() {
		return jourc;
	}

	public void setJourc(String jourc) {
		this.jourc = jourc;
	}

	public String getDebsemc() {
		return debsemc;
	}

	public void setDebsemc(String debsemc) {
		this.debsemc = debsemc;
	}

	public String getHeuredc() {
		return heuredc;
	}

	public void setHeuredc(String heuredc) {
		this.heuredc = heuredc;
	}

	public String getTypec() {
		return typec;
	}

	public void setTypec(String typec) {
		this.typec = typec;
	}

	public String getHeurefc() {
		return heurefc;
	}

	public void setHeurefc(String heurefc) {
		this.heurefc = heurefc;
	}



	@Override
	public int hashCode() {
		return Objects.hash(debsemc, grpc, heuredc, jourc);
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Creneau)) {
			return false;
		}
		Creneau other = (Creneau) obj;
		return Objects.equals(debsemc, other.debsemc) && Objects.equals(grpc, other.grpc)
				&& Objects.equals(heuredc, other.heuredc) && Objects.equals(jourc, other.jourc);
	}



	@Override
	public String toString() {
		return "Creneau [jourc=" + jourc + ", debsemc=" + debsemc + ", heuredc=" + heuredc + ", typec=" + typec
				+ ", heurefc=" + heurefc + ", id_enseign=" + id_enseign + ", matc=" + matc + ", grpc=" + grpc
				+ ", nsalle=" + nsalle + "]";
	}



	public Collection<Enseignant> getEnsc() {
		return Ensc;
	}



	public void setEnsc(Collection<Enseignant> ensc) {
		Ensc = ensc;
	}



	public Collection<Salle> getSalC() {
		return SalC;
	}



	public void setSalC(Collection<Salle> salC) {
		SalC = salC;
	}
	
	

}

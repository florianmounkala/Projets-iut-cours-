package modele;


import java.util.Objects;

public class Formation {
	
	private String idfor;
	private String libf;
	private int nbgrc;
	private int nbgrtd;
	private int nbgrtp;
	
	public Formation(String idfor, String libf, int nbgrc, int nbgrtd, int nbgrtp) {
		this.idfor = idfor;
		this.libf = libf;
		this.nbgrc = nbgrc;
		this.nbgrtd = nbgrtd;
		this.nbgrtp = nbgrtp;
		
	}

	public String getIdfor() {
		return idfor;
	}

	public void setIdfor(String idfor) {
		this.idfor = idfor;
	}

	public String getLibf() {
		return libf;
	}

	public void setLibf(String libf) {
		this.libf = libf;
	}

	public int getNbgrc() {
		return nbgrc;
	}

	public void setNbgrc(int nbgrc) {
		this.nbgrc = nbgrc;
	}

	public int getNbgrtd() {
		return nbgrtd;
	}

	public void setNbgrtd(int nbgrtd) {
		this.nbgrtd = nbgrtd;
	}

	public int getNbgrtp() {
		return nbgrtp;
	}

	public void setNbgrtp(int nbgrtp) {
		this.nbgrtp = nbgrtp;
	}

	@Override
	public int hashCode() {
		return Objects.hash(idfor);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Formation)) {
			return false;
		}
		Formation other = (Formation) obj;
		return idfor == other.idfor;
	}

	@Override
	public String toString() {
		return "Formation [idfor=" + idfor + ", libf=" + libf + ", nbgrc=" + nbgrc + ", nbgrtd=" + nbgrtd + ", nbgrtp="
				+ nbgrtp + "]";
	}

	
	
	

}

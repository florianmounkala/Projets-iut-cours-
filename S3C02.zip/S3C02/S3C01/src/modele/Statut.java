package modele;

import java.util.Objects;

public class Statut {
	
	private String grade;
	private int nbheurst;
	
	public Statut(String grade, int nbheurst) {
		this.grade = grade;
		this.nbheurst = nbheurst;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public int getNbheurst() {
		return nbheurst;
	}

	public void setNbheurst(int nbheurst) {
		this.nbheurst = nbheurst;
	}

	@Override
	public int hashCode() {
		return Objects.hash(grade);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Statut)) {
			return false;
		}
		Statut other = (Statut) obj;
		return Objects.equals(grade, other.grade);
	}

	@Override
	public String toString() {
		return "Statut [grade=" + grade + ", nbheurst=" + nbheurst + "]";
	}
	
	

}

package modele;

import java.util.Collection;
import java.util.HashSet;
import java.util.Objects;

public class Salle {
	
	private String nsalle;
	private String tsal;
	private int capacite;
	
	
	
	public Salle(String nsalle, String tsal, int capacite) {
		this.nsalle = nsalle;
		this.tsal = tsal;
		this.capacite = capacite;
	}


	public String getNsalle() {
		return nsalle;
	}


	public void setNsalle(String nsalle) {
		this.nsalle = nsalle;
	}


	public String getTsal() {
		return tsal;
	}


	public void setTsal(String tsal) {
		this.tsal = tsal;
	}


	public int getCapacite() {
		return capacite;
	}


	public void setCapacite(int capacite) {
		this.capacite = capacite;
	}





	@Override
	public int hashCode() {
		return Objects.hash(nsalle);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Salle)) {
			return false;
		}
		Salle other = (Salle) obj;
		return nsalle == other.nsalle;
	}


	@Override
	public String toString() {
		return "Salle [nsalle=" + nsalle + ", tsal=" + tsal + ", capacite=" + capacite  + "]";
	}
	
	
	

}

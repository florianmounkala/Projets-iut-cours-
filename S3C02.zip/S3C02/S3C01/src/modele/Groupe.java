package modele;

import java.util.Collection;
import java.util.HashSet;
import java.util.Objects;

public class Groupe {
	
	private String grpc;
	private String anneec;
	private int eff;
	private Formation idfor;
	private Collection<Formation> annee;
	
	
	public Groupe(String grpc, String anneec, int eff, Formation idfor) {
		this.grpc = grpc;
		this.anneec = anneec;
		this.eff = eff;
		this.idfor = idfor;
		this.annee = new HashSet<>();
	}


	public String getGrpc() {
		return grpc;
	}


	public void setGrpc(String grpc) {
		this.grpc = grpc;
	}


	public String getAnneec() {
		return anneec;
	}


	public void setAnneec(String anneec) {
		this.anneec = anneec;
	}


	public int getEff() {
		return eff;
	}


	public void setEff(int eff) {
		this.eff = eff;
	}


	public Collection<Formation> getAnnee() {
		return annee;
	}


	public void setAnnee(Collection<Formation> annee) {
		this.annee = annee;
	}


	@Override
	public int hashCode() {
		return Objects.hash(grpc);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Groupe)) {
			return false;
		}
		Groupe other = (Groupe) obj;
		return Objects.equals(grpc, other.grpc);
	}


	@Override
	public String toString() {
		return "Groupe [grpc=" + grpc + ", anneec=" + anneec + ", eff=" + eff + ", idfor=" + idfor + ", annee=" + annee
				+ "]";
	}
	
	

}

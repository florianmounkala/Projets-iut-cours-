package modele;

import java.util.Objects;

public class Enseignant {
	
	private String id_enseignant;
	private String nom;
	private String prenom;
	private int nbhdisp;
	
	private Statut Grade;
	
	
	public Statut getGrade() {
		return Grade;
	}


	public void setGrade(Statut grade) {
		Grade = grade;
	}
	
	
	public Enseignant(String id_enseignant, String nom, String prenom, int nbhdisp, Statut Grade) {
		this.id_enseignant = id_enseignant;
		this.Grade = Grade;
		this.nom = nom;
		this.prenom = prenom;
		this.nbhdisp = nbhdisp;
	}
	
	
	public String getId_enseignant() {
		return id_enseignant;
	}


	public void setId_enseignant(String id_enseignant) {
		this.id_enseignant = id_enseignant;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public String getPrenom() {
		return prenom;
	}


	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}


	public int getNbhdisp() {
		return nbhdisp;
	}


	public void setNbhdisp(int nbhdisp) {
		this.nbhdisp = nbhdisp;
	}


	@Override
	public int hashCode() {
		return Objects.hash(id_enseignant);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Enseignant)) {
			return false;
		}
		Enseignant other = (Enseignant) obj;
		return id_enseignant == other.id_enseignant;
	}


	@Override
	public String toString() {
		return "Enseignant [id_enseignant=" + id_enseignant + ", nom=" + nom + ", prenom=" + prenom + ", nbhdisp="
				+ nbhdisp  + ", Grade=" + Grade + "]";
	}
	
	

	

}

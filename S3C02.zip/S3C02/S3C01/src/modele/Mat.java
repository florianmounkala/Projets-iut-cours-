package modele;


import java.util.Objects;

public class Mat {
	
	private String matc;
	private String intc;
	
	
	public Mat(String matc, String intc) {
		this.matc = matc;
		this.intc = intc;
	}


	public String getMatc() {
		return matc;
	}


	public void setMatc(String matc) {
		this.matc = matc;
	}


	public String getIntc() {
		return intc;
	}


	public void setIntc(String intc) {
		this.intc = intc;
	}


	@Override
	public int hashCode() {
		return Objects.hash(matc);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Mat)) {
			return false;
		}
		Mat other = (Mat) obj;
		return Objects.equals(matc, other.matc);
	}


	@Override
	public String toString() {
		return "Mat [matc=" + matc + ", intc=" + intc + "]";
	}
	
	

}

package controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import vue.Connexion;
import vue.FenetrePrincipale;

public class GestionConnexion implements ActionListener {
	
	private Connexion c;
	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		JButton button = (JButton) e.getSource();
		switch(button.getText()) {
		case "Annuler":
			this.c.dispose();
			break;
		case "Connecter":
			FenetrePrincipale f = (FenetrePrincipale)this.c.getTopLevelAncestor();
			f.setEstConnecte(true);
			f.activerItems(true);
			this.c.dispose();
		}
	}
	
	public GestionConnexion(Connexion c) {
		this.c = c;
	}
	

}

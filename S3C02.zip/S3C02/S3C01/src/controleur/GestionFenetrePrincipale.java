package controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;

import vue.AfficherCreneau;
import vue.Connexion;
import vue.FenetrePrincipale;

public class GestionFenetrePrincipale implements ActionListener {
	private FenetrePrincipale fp;
	public GestionFenetrePrincipale(FenetrePrincipale f) {
		this.fp = f;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		JMenuItem item = (JMenuItem) e.getSource();
		switch(item.getText()) {
		case "Quitter":
			this.fp.dispose();
			break;
		case "Connecter":
			Connexion c = new Connexion();
			this.fp.getLayeredPane().add(c);
			c.setVisible(true);
			this.fp.estConnecte = true;
			this.fp.activerItems(this.fp.estConnecte);
			break;
		case "Deconnecter":
			this.fp.estConnecte = false;
			this.fp.activerItems(this.fp.estConnecte);
		case "Creneau": 
				AfficherCreneau a = new AfficherCreneau();
				this.fp.getLayeredPane().getTopLevelAncestor().add(a);
				a.setVisible(true);
				break;
		}	
	}
	
}

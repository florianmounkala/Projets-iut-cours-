package controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import vue.AfficherCreneau;
import vue.FenetrePrincipale;
import vue.SaisirCreneau;

public class GestionAfficherCreneau implements ActionListener{

	private AfficherCreneau AC;
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		JButton item = (JButton) e.getSource();
		FenetrePrincipale fen = (FenetrePrincipale) this.AC.getTopLevelAncestor();
		switch(item.getText()) {
		case "Annuler":
			this.AC.dispose();
			break;
		case "Inserer":
			SaisirCreneau s = new SaisirCreneau();
			fen.getLayeredPane().add(s);
			s.setVisible(true);
			s.moveToFront();
			break;
		}
	}
	
	public GestionAfficherCreneau(AfficherCreneau ac) {
		this.AC = ac;
	}

}

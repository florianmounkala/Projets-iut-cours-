package controleur;

import javax.swing.event.ListSelectionListener;

import vue.AfficherCreneau;

public class GestionTableCreneau implements ListSelectionListener{
	private AfficherCreneau AC;
	public GestionTableCreneau(AfficherCreneau x) {
		this.AC = x;
	}
	
	
}

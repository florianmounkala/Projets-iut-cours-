package controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JTable;

import vue.AfficherCreneau;
import vue.SaisirCreneau;

public class GestionSaisirCreneau implements ActionListener{

	private SaisirCreneau SC;
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		JButton item = (JButton) e.getSource();
		switch(item.getText()) {
			case "Annuler":
				this.SC.dispose();
				break;
			case "Inserer":
				AfficherCreneau a = (AfficherCreneau)this.SC.getTopLevelAncestor();
				
			}
	}
	
	public GestionSaisirCreneau(SaisirCreneau s, JTable table) {
		this.SC = s;
	}
	
}

package vue;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPasswordField;
import java.awt.GridLayout;
import java.awt.CardLayout;
import java.awt.Color;
import javax.swing.SwingConstants;

import controleur.GestionConnexion;

import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Connexion extends JInternalFrame {
	private JTextField textField;
	private JPasswordField passwordField;
	private GestionConnexion gestionClic;


	/**
	 * Create the frame.
	 */
	public Connexion() {
		this.gestionClic = new GestionConnexion(this);
		getContentPane().setBackground(Color.CYAN);
		getContentPane().setForeground(Color.RED);
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 1, 343, 53);
		getContentPane().add(panel);
		
		JLabel lblNewLabel = new JLabel("login : ");
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		panel.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(textField);
		textField.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 54, 343, 53);
		getContentPane().add(panel_1);
		
		JLabel lblNewLabel_1 = new JLabel("mot de passe : ");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		panel_1.add(lblNewLabel_1);
		
		passwordField = new JPasswordField();
		passwordField.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(passwordField);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 107, 343, 53);
		getContentPane().add(panel_2);
		
		JButton btnNewButton = new JButton("Connecter");
		btnNewButton.addActionListener(this.gestionClic);
		panel_2.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Annuler");
		btnNewButton_1.addActionListener(this.gestionClic);
		panel_2.add(btnNewButton_1);
		setBounds(100, 100, 359, 191);

	}

	public void actionPerformed(ActionEvent e) {
		JButton button = (JButton) e.getSource();
		switch(button.getText()) {
		case "Annuler":
			this.dispose();
			break;
		case "Connecter":
			FenetrePrincipale f = (FenetrePrincipale)this.getTopLevelAncestor();
			f.setEstConnecte(true);
			f.activerItems(true);
			this.dispose();
		}
	}
}

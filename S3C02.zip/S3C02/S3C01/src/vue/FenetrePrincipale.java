package vue;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controleur.GestionFenetrePrincipale;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FenetrePrincipale extends JFrame {

	public boolean isEstConnecte() {
		return estConnecte;
	}

	public void setEstConnecte(boolean estConnecte) {
		this.estConnecte = estConnecte;
	}

	private JPanel contentPane;
	private JMenu Connexion;
	private JMenuItem deconnecter;
	private JMenuItem creneau;
	public boolean estConnecte = false;
	private JMenuItem connecter;
	private GestionFenetrePrincipale gestionClic;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FenetrePrincipale frame = new FenetrePrincipale();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FenetrePrincipale() {
		this.gestionClic = new GestionFenetrePrincipale(this);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu Fichier = new JMenu("Fichier");
		menuBar.add(Fichier);
		
		JMenuItem Quitter = new JMenuItem("Quitter");
		Quitter.addActionListener(this.gestionClic);
		Fichier.add(Quitter);
		
		Connexion = new JMenu("Connexion");
		menuBar.add(Connexion);
		
		connecter = new JMenuItem("Connecter");
		connecter.addActionListener(this.gestionClic);
		
		Connexion.add(connecter);
		
		deconnecter = new JMenuItem("Deconnecter");
		deconnecter.addActionListener(this.gestionClic);
		deconnecter.setEnabled(false);
		deconnecter.setForeground(new Color(192, 192, 192));
		Connexion.add(deconnecter);
		
		
		JMenu Affichage = new JMenu("Affichage");
		menuBar.add(Affichage);
		
		creneau = new JMenuItem("Creneau");
		creneau.addActionListener(this.gestionClic);
		creneau.setEnabled(false);
		
		creneau.setForeground(new Color(192, 192, 192));
		Affichage.add(creneau);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	}
	
	public void actionPerformed(ActionEvent e) {
		JMenuItem item = (JMenuItem) e.getSource();
		switch(item.getText()) {
		case "Quitter":
			this.dispose();
			break;
		case "Connecter":
			Connexion c = new Connexion();
			this.getLayeredPane().add(c);
			c.setVisible(true);
			this.estConnecte = true;
			this.activerItems(estConnecte);
			break;
		case "Deconnecter":
			this.estConnecte = false;
			this.activerItems(estConnecte);
		case "Creneau": 
				AfficherCreneau a = new AfficherCreneau();
				this.getLayeredPane().getTopLevelAncestor().add(a);
				a.setVisible(true);
				break;
		}
	}
	
	public void activerItems(boolean activate) {
		
		if(activate == true) {
			deconnecter.setEnabled(activate);
			creneau.setEnabled(activate);
			deconnecter.setForeground(new Color(0, 0, 0));
			creneau.setForeground(new Color(0, 0, 0));
			connecter.setEnabled(!activate);
			connecter.setForeground(new Color(192, 192, 192));
		}
		else {
			deconnecter.setEnabled(activate);
			deconnecter.setForeground(new Color(192, 192, 192));
			creneau.setEnabled(activate);
			creneau.setForeground(new Color(192, 192, 192));
			connecter.setEnabled(!activate);
			connecter.setForeground(new Color(0, 0, 0));
			
		}
	}
		
	
}

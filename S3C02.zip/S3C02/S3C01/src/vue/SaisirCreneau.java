package vue;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;

import controleur.GestionSaisirCreneau;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SaisirCreneau extends JInternalFrame {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTable TableCreneau;
	private GestionSaisirCreneau gestionClic;
	
	/**
	 * Create the frame.
	 */
	public SaisirCreneau(JTable TC) {
		this.TableCreneau = TC;
		this.gestionClic = new GestionSaisirCreneau(this, TC);
		setBounds(100, 100, 563, 393);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Debsemc :");
		lblNewLabel.setBounds(27, 30, 83, 14);
		getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(119, 27, 196, 20);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("JourC : ");
		lblNewLabel_1.setBounds(27, 81, 46, 14);
		getContentPane().add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(119, 78, 196, 20);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("HeureDC :");
		lblNewLabel_2.setBounds(27, 138, 64, 14);
		getContentPane().add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setBounds(119, 135, 196, 20);
		getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Identifiant GprC :");
		lblNewLabel_3.setBounds(27, 196, 100, 14);
		getContentPane().add(lblNewLabel_3);
		
		textField_3 = new JTextField();
		textField_3.setBounds(119, 193, 196, 20);
		getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("HeureFC :");
		lblNewLabel_4.setBounds(27, 241, 64, 14);
		getContentPane().add(lblNewLabel_4);
		
		textField_4 = new JTextField();
		textField_4.setBounds(118, 238, 197, 20);
		getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("TypeC :");
		lblNewLabel_5.setBounds(27, 292, 46, 14);
		getContentPane().add(lblNewLabel_5);
		
		textField_5 = new JTextField();
		textField_5.setBounds(119, 289, 196, 20);
		getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		JButton btnNewButton = new JButton("Inserer");
		btnNewButton.addActionListener(this.gestionClic);
		btnNewButton.setBounds(119, 329, 89, 23);
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Annuler");
		btnNewButton_1.addActionListener(this.gestionClic);
		btnNewButton_1.setBounds(292, 329, 89, 23);
		getContentPane().add(btnNewButton_1);

	}
	public void actionPerformed(ActionEvent e) {
		JButton item = (JButton) e.getSource();
		switch(item.getText()) {
			case "Annuler":
				this.dispose();
				break;
			case "Inserer":
				AfficherCreneau a = (AfficherCreneau)this.getTopLevelAncestor();
				
			}
		
			
		}

	public JTextField getTextField() {
		return textField;
	}

	public JTextField getTextField_1() {
		return textField_1;
	}

	public JTextField getTextField_2() {
		return textField_2;
	}

	public JTextField getTextField_3() {
		return textField_3;
	}

	public JTextField getTextField_4() {
		return textField_4;
	}

	public JTextField getTextField_5() {
		return textField_5;
	}
		
	}



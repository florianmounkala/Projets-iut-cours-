package vue;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import controleur.GestionAfficherCreneau;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AfficherCreneau extends JInternalFrame  {
	private JTable table;
	private JTable table_1;
	private JTable table_2;
	private JTable table_3;
	private GestionAfficherCreneau gestionClic;


	/**
	 * Create the frame.
	 */
	public AfficherCreneau() {
		this.gestionClic = new GestionAfficherCreneau(this);
		setBounds(100, 100, 639, 436);
		getContentPane().setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(20, 21, 494, 144);
		getContentPane().add(scrollPane_2);
		
		table = new JTable();
		scrollPane_2.setViewportView(table);
		table.setBackground(Color.WHITE);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"", "", "", "", "", ""},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
			},
			new String[] {
				"DebsemC", "JourC", "HeureDC", "HeureFC", "TypeC", "GrpC"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(20, 181, 203, 42);
		getContentPane().add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.setEnabled(false);
		table_1.setFillsViewportHeight(true);
		scrollPane_1.setViewportView(table_1);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
				{"", ""},
				{"", null},
			},
			new String[] {
				"MatC", "IntC"
			}
		));
		
		JLabel lblNewLabel = new JLabel("Cr\u00E9neaux");
		lblNewLabel.setBounds(20, 0, 79, 25);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Mati\u00E8re :");
		lblNewLabel_1.setBounds(20, 167, 46, 14);
		getContentPane().add(lblNewLabel_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setEnabled(false);
		scrollPane.setBounds(20, 248, 256, 96);
		getContentPane().add(scrollPane);
		
		table_2 = new JTable();
		scrollPane.setViewportView(table_2);
		table_2.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
			},
			new String[] {
				"IdEnseign", "Nom", "Prenom", "Statut"
			}
		));
		
		JLabel lblNewLabel_2 = new JLabel("Enseignant :");
		lblNewLabel_2.setBounds(20, 228, 79, 14);
		getContentPane().add(lblNewLabel_2);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setEnabled(false);
		scrollPane_3.setBounds(401, 209, 212, 96);
		getContentPane().add(scrollPane_3);
		
		table_3 = new JTable();
		scrollPane_3.setViewportView(table_3);
		table_3.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"NSalle", "TSal", "Capactite"
			}
		));
		
		JLabel lblNewLabel_3 = new JLabel("Salle :");
		lblNewLabel_3.setBounds(403, 190, 46, 14);
		getContentPane().add(lblNewLabel_3);
		
		JButton btnNewButton = new JButton("Charger");
		btnNewButton.addActionListener(this.gestionClic);
		btnNewButton.setBounds(29, 372, 89, 23);
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Inserer");
		btnNewButton_1.addActionListener(this.gestionClic);
		btnNewButton_1.setBounds(148, 372, 89, 23);
		getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Mise a jour");
		btnNewButton_2.addActionListener(this.gestionClic);
		btnNewButton_2.setBounds(263, 372, 89, 23);
		getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Supprimer");
		btnNewButton_3.addActionListener(this.gestionClic);
		btnNewButton_3.setBounds(382, 372, 89, 23);
		getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Annuler");
		btnNewButton_4.addActionListener(this.gestionClic);
		btnNewButton_4.setBounds(502, 372, 89, 23);
		getContentPane().add(btnNewButton_4);
		
	}
	
	public JTable getTable() {
		return table;
	}

	public JTable getTable_1() {
		return table_1;
	}

	public JTable getTable_2() {
		return table_2;
	}

	public JTable getTable_3() {
		return table_3;
	}
	
	public void actionPerformed(ActionEvent e) {
		JButton item = (JButton) e.getSource();
		FenetrePrincipale fen = (FenetrePrincipale) this.getTopLevelAncestor();
		switch(item.getText()) {
		case "Annuler":
			this.dispose();
			break;
		case "Inserer":
			SaisirCreneau s = new SaisirCreneau();
			fen.getLayeredPane().add(s);
			s.setVisible(true);
			s.moveToFront();
			break;
		}
	}
}


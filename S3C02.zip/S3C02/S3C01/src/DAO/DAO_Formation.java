package DAO;
import modele.Formation;

public class DAO_Formation implements Dao<Formation>{

	@Override
	public void select(Formation element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Formation element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Formation element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(Formation element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Formation findByld(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Formation findAll() {
		// TODO Auto-generated method stub
		return null;
	}




}

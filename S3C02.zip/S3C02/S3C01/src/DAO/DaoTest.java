package DAO;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import modele.Creneau;
import modele.Enseignant;
import modele.Formation;
import modele.Groupe;
import modele.Mat;
import modele.Salle;
import modele.Statut;


public class DaoTest 
	{
		private static final Collection<Creneau> CRENEAUX = new HashSet<> () ;
		private static final Collection<Enseignant> ENSEIGNANTS = new HashSet<> () ;
		private static final Collection<Formation> FORMATIONS = new HashSet<> () ;
		private static final Collection<Groupe> GROUPES = new HashSet<> () ;
		private static final Collection<Mat> MATS = new HashSet<> () ;
		private static final Collection<Salle> SALLES = new HashSet<> () ;
		private static final Collection<Statut> STATUTS = new HashSet<> () ;

		static
		{	
			Formation fS1   = new Formation ("S1  ", "DUT Premiere Annee - Semestre 1", 1, 6, 12) ;
			Formation fAS   = new Formation ("AS  ", "DUT Annee Speciale", 1, 1, 1) ;
			Formation fS3   = new Formation ("S3  ", "DUT Seconde Annee - Semestre 1", 1, 5, 5) ;
			Formation fS2   = new Formation ("S2  ", "DUT Premiere Annee - Semestre 2", 1, 6, 6) ;
			Formation fDQL  = new Formation ("DQL ", "Licence Developpement Qualite Logiciel", 1, 1, 1) ;
			Formation fS4   = new Formation ("S4  ", "DUT Seconde Annee - Semestre 2", 1, 4, 4) ;
			Formation fGT   = new Formation ("GT  ", "Licence Bases de Donnees Avancees", 1, 2, 2) ;
			
			DaoTest.FORMATIONS.add(fS1) ;
			DaoTest.FORMATIONS.add(fAS) ;
			DaoTest.FORMATIONS.add(fS3) ;
			DaoTest.FORMATIONS.add(fS2) ;
			DaoTest.FORMATIONS.add(fDQL) ;
			DaoTest.FORMATIONS.add(fS4) ;
			DaoTest.FORMATIONS.add(fGT) ;

			Groupe gInAS = new Groupe ("InAS", "AS ", 23, fAS ) ;
			Groupe gInS1A1 = new Groupe ("InS1A1", "S1 ", 15, fS1 ) ;
			Groupe gInS1A2 = new Groupe ("InS1A2", "S1 ", 14, fS1 ) ;
			Groupe gInS1B1 = new Groupe ("InS1B1", "S1 ", 14, fS1 ) ;
			Groupe gInS1B2 = new Groupe ("InS1B2", "S1 ", 14, fS1 ) ;
			Groupe gInS1C = new Groupe ("InS1C", "S1 ", 28, fS1 ) ;
			Groupe gInS1D = new Groupe ("InS1D", "S1 ", 30, fS1 ) ;
			Groupe gInS1E1 = new Groupe ("InS1E1", "S1 ", 14, fS1 ) ;
			Groupe gInS1E2 = new Groupe ("InS1E2", "S1 ", 15, fS1 ) ;
			Groupe gInS1F1 = new Groupe ("InS1F1", "S1 ", 15, fS1 ) ;			

			DaoTest.GROUPES.add(gInAS) ;
			DaoTest.GROUPES.add(gInS1A1) ;
			DaoTest.GROUPES.add(gInS1A2) ;
			DaoTest.GROUPES.add(gInS1B1) ;
			DaoTest.GROUPES.add(gInS1B2) ;
			DaoTest.GROUPES.add(gInS1C) ;
			DaoTest.GROUPES.add(gInS1D) ;
			DaoTest.GROUPES.add(gInS1E1) ;
			DaoTest.GROUPES.add(gInS1E2) ;
			DaoTest.GROUPES.add(gInS1F1) ;
			
			Mat mInM1101 = new Mat ("InM1101", "") ;
			Mat mInM1202 = new Mat ("InM1202", "Alg�bre lin�aire") ;
			Mat mInM1205 = new Mat ("InM1205", "Expression-Communication - Fondamentaux de la communication") ;
			Mat mInM1206 = new Mat ("InM1206", "Anglais et Informatique") ;
			Mat minA1109 = new Mat ("inA1109", "") ;
			
			DaoTest.MATS.add(mInM1101) ;
			DaoTest.MATS.add(mInM1202) ;
			DaoTest.MATS.add(mInM1205) ;
			DaoTest.MATS.add(mInM1206) ;
			DaoTest.MATS.add(minA1109) ;
					
			Creneau c190916jeudi0800InS1A1 = new Creneau ("19/09/16", "jeudi", "08:00", "TP", "09:30", mInM1206, gInS1A1 ) ;
			Creneau c190916jeudi0800InS1B2 = new Creneau ("19/09/16", "jeudi", "08:00", "TP", "09:30", mInM1205, gInS1B2 ) ;
			Creneau c190916jeudi0800InS1A2 = new Creneau ("19/09/16", "jeudi", "08:00", "TP", "09:30", mInM1206, gInS1A2 ) ;
			Creneau c190916jeudi0800InS1B1 = new Creneau ("19/09/16", "jeudi", "08:00", "TP", "09:30", mInM1205, gInS1B1 ) ;
			Creneau c190916jeudi0800InAS = new Creneau ("19/09/16", "jeudi", "08:00", "TD", "09:30", minA1109, gInAS ) ;
			Creneau c190916jeudi0800InS1E1 = new Creneau ("19/09/16", "jeudi", "08:00", "TP", "09:30", mInM1101, gInS1E1 ) ;
			Creneau c190916jeudi0800InS1C = new Creneau ("19/09/16", "jeudi", "08:00", "TD", "09:30", mInM1202, gInS1C ) ;
			Creneau c190916jeudi0800InS1D = new Creneau ("19/09/16", "jeudi", "08:00", "TD", "09:30", mInM1202, gInS1D ) ;
			Creneau c190916jeudi0800InS1E2 = new Creneau ("19/09/16", "jeudi", "08:00", "TP", "09:30", mInM1101, gInS1E2 ) ;
			Creneau c190916jeudi0800InS1F1 = new Creneau ("19/09/16", "jeudi", "08:00", "TP", "09:30", mInM1101, gInS1F1 ) ;

		
			DaoTest.CRENEAUX.add(c190916jeudi0800InS1A1) ;
			DaoTest.CRENEAUX.add(c190916jeudi0800InS1B2) ;
			DaoTest.CRENEAUX.add(c190916jeudi0800InS1A2) ;
			DaoTest.CRENEAUX.add(c190916jeudi0800InS1B1) ;
			DaoTest.CRENEAUX.add(c190916jeudi0800InAS) ;
			DaoTest.CRENEAUX.add(c190916jeudi0800InS1E1) ;
			DaoTest.CRENEAUX.add(c190916jeudi0800InS1C) ;
			DaoTest.CRENEAUX.add(c190916jeudi0800InS1D) ;
			DaoTest.CRENEAUX.add(c190916jeudi0800InS1E2) ;
			DaoTest.CRENEAUX.add(c190916jeudi0800InS1F1) ;
			
			Statut sPRCE = new Statut ("PRCE", 384) ;
			Statut sVACA = new Statut ("VACA", 184) ;
			Statut sCDOC = new Statut ("CDOC", 64) ;
			Statut sATER = new Statut ("ATER", 96) ;
			Statut sPROF = new Statut ("PROF", 192) ;
			Statut sPRAG = new Statut ("PRAG", 384) ;
			Statut sMCF  = new Statut ("MCF ", 192) ;
			
			DaoTest.STATUTS.add(sPRCE) ;
			DaoTest.STATUTS.add(sVACA) ;
			DaoTest.STATUTS.add(sCDOC) ;
			DaoTest.STATUTS.add(sATER) ;
			DaoTest.STATUTS.add(sPROF) ;
			DaoTest.STATUTS.add(sPRAG) ;
			DaoTest.STATUTS.add(sMCF) ;

			Enseignant eADM = new Enseignant ("ADM", "AUDOUX", "Marguerite", 0, sMCF ) ;
			Enseignant eBZH = new Enseignant ("BZH", "BAZIN", "Herv�", 0, sMCF ) ;
			Enseignant eCMA = new Enseignant ("CMA", "CAMUS", "Albert", 0, sMCF ) ;
			Enseignant eDBJ = new Enseignant ("DBJ", "DU BELLAY", "Joachim", 0, sPRCE) ;
			Enseignant eDUA = new Enseignant ("DUA", "DAUDET", "Alphonse", 0, sMCF ) ;
			Enseignant eEUP = new Enseignant ("EUP", "ELUARD", "Paul", 0, sPRCE) ;
			Enseignant eFUA = new Enseignant ("FUA", "FOURNIER", "Alain", 0, sPRCE) ;
			Enseignant ePNF = new Enseignant ("PNF", "PONGE", "Francis", 0, sMCF ) ;
			Enseignant eSAA = new Enseignant ("SAA", "STAEL", "Anne Louise", 0, sPRCE) ;
			Enseignant eSRN = new Enseignant ("SRN", "SARRAUTE", "Nathalie", 0, sMCF ) ;
			
			DaoTest.ENSEIGNANTS.add(eADM) ;
			DaoTest.ENSEIGNANTS.add(eBZH) ;
			DaoTest.ENSEIGNANTS.add(eCMA) ;
			DaoTest.ENSEIGNANTS.add(eDBJ) ;
			DaoTest.ENSEIGNANTS.add(eDUA) ;
			DaoTest.ENSEIGNANTS.add(eEUP) ;
			DaoTest.ENSEIGNANTS.add(eFUA) ;		
			DaoTest.ENSEIGNANTS.add(ePNF) ;
			DaoTest.ENSEIGNANTS.add(eSAA) ;
			DaoTest.ENSEIGNANTS.add(eSRN) ;
			
			java.util.Collection<Enseignant> en190916jeudi0800InAS = new HashSet<>() ;
			java.util.Collection<Enseignant> en190916jeudi0800InS1A1 = new HashSet<>() ;
			java.util.Collection<Enseignant> en190916jeudi0800InS1A2 = new HashSet<>() ;
			java.util.Collection<Enseignant> en190916jeudi0800InS1B1 = new HashSet<>() ;
			java.util.Collection<Enseignant> en190916jeudi0800InS1B2 = new HashSet<>() ;
			java.util.Collection<Enseignant> en190916jeudi0800InS1C = new HashSet<>() ;
			java.util.Collection<Enseignant> en190916jeudi0800InS1D = new HashSet<>() ;
			java.util.Collection<Enseignant> en190916jeudi0800InS1E1 = new HashSet<>() ;
			java.util.Collection<Enseignant> en190916jeudi0800InS1E2 = new HashSet<>() ;
			java.util.Collection<Enseignant> en190916jeudi0800InS1F1 = new HashSet<>() ;		
			
			c190916jeudi0800InAS.setEnsc(en190916jeudi0800InAS) ;
			c190916jeudi0800InS1A1.setEnsc(en190916jeudi0800InS1A1) ;
			c190916jeudi0800InS1A2.setEnsc(en190916jeudi0800InS1A2) ;
			c190916jeudi0800InS1B1.setEnsc(en190916jeudi0800InS1B1) ;
			c190916jeudi0800InS1B2.setEnsc(en190916jeudi0800InS1B2) ;
			c190916jeudi0800InS1C.setEnsc(en190916jeudi0800InS1C) ;
			c190916jeudi0800InS1D.setEnsc(en190916jeudi0800InS1D) ;
			c190916jeudi0800InS1E1.setEnsc(en190916jeudi0800InS1E1) ;
			c190916jeudi0800InS1E2.setEnsc(en190916jeudi0800InS1E2) ;
			c190916jeudi0800InS1F1.setEnsc(en190916jeudi0800InS1F1) ;
			
			en190916jeudi0800InAS.add(eADM) ;
			en190916jeudi0800InS1A1.add(eEUP) ;
			en190916jeudi0800InS1A2.add(eSRN) ;
			en190916jeudi0800InS1B1.add(eSAA) ;
			en190916jeudi0800InS1B2.add(eDBJ) ;
			en190916jeudi0800InS1C.add(ePNF) ;
			en190916jeudi0800InS1D.add(eBZH) ;
			en190916jeudi0800InS1E1.add(eCMA) ;
			en190916jeudi0800InS1E2.add(eDUA) ;
			en190916jeudi0800InS1F1.add(eFUA) ;

			
			Salle saIN116 = new Salle ("IN116", "TD", 30) ;
			Salle saIN204 = new Salle ("IN204", "TD", 30) ;
			Salle saIN205 = new Salle ("IN205", "TD", 30) ;
			Salle saIN210 = new Salle ("IN210", "TD", 30) ;
			Salle saIN212 = new Salle ("IN212", "TD", 30) ;
			Salle saInAmbre = new Salle ("InAmbre", "TP", 30) ;
			Salle saInDiamant = new Salle ("InDiamant", "TP", 30) ;
			Salle saInJade = new Salle ("InJade", "TP", 28) ;
			Salle saInOpale = new Salle ("InOpale", "TP", 30) ;
			
			DaoTest.SALLES.add(saIN116) ;
			DaoTest.SALLES.add(saIN204) ;
			DaoTest.SALLES.add(saIN205) ;
			DaoTest.SALLES.add(saIN210) ;
			DaoTest.SALLES.add(saIN212) ;
			DaoTest.SALLES.add(saInAmbre) ;
			DaoTest.SALLES.add(saInDiamant) ;		
			DaoTest.SALLES.add(saInJade) ;
			DaoTest.SALLES.add(saInOpale) ;
			
			java.util.Collection<Salle> salle190916jeudi0800InAS = new HashSet<>() ;
			java.util.Collection<Salle> salle190916jeudi0800InS1A1 = new HashSet<>() ;
			java.util.Collection<Salle> salle190916jeudi0800InS1A2 = new HashSet<>() ;
			java.util.Collection<Salle> salle190916jeudi0800InS1B1 = new HashSet<>() ;
			java.util.Collection<Salle> salle190916jeudi0800InS1B2 = new HashSet<>() ;
			java.util.Collection<Salle> salle190916jeudi0800InS1C = new HashSet<>() ;
			java.util.Collection<Salle> salle190916jeudi0800InS1D = new HashSet<>() ;
			java.util.Collection<Salle> salle190916jeudi0800InS1E1 = new HashSet<>() ;
			java.util.Collection<Salle> salle190916jeudi0800InS1E2 = new HashSet<>() ;
			java.util.Collection<Salle> salle190916jeudi0800InS1F1 = new HashSet<>() ;
			
			c190916jeudi0800InAS.setSalC(salle190916jeudi0800InAS) ;
			c190916jeudi0800InS1A1.setSalC(salle190916jeudi0800InS1A1) ;
			c190916jeudi0800InS1A2.setSalC(salle190916jeudi0800InS1A2) ;
			c190916jeudi0800InS1B1.setSalC(salle190916jeudi0800InS1B1) ;
			c190916jeudi0800InS1B2.setSalC(salle190916jeudi0800InS1B2) ;
			c190916jeudi0800InS1C.setSalC(salle190916jeudi0800InS1C) ;
			c190916jeudi0800InS1D.setSalC(salle190916jeudi0800InS1D) ;
			c190916jeudi0800InS1E1.setSalC(salle190916jeudi0800InS1E1) ;
			c190916jeudi0800InS1E2.setSalC(salle190916jeudi0800InS1E2) ;
			c190916jeudi0800InS1F1.setSalC(salle190916jeudi0800InS1F1) ;

			salle190916jeudi0800InAS.add(saInDiamant) ;
			salle190916jeudi0800InS1A1.add(saIN116) ;
			salle190916jeudi0800InS1A2.add(saIN116) ;
			salle190916jeudi0800InS1B1.add(saIN210) ;
			salle190916jeudi0800InS1B2.add(saIN212) ;
			salle190916jeudi0800InS1C.add(saIN204) ;
			salle190916jeudi0800InS1D.add(saIN205) ;
			salle190916jeudi0800InS1E1.add(saInAmbre) ;
			salle190916jeudi0800InS1E2.add(saInOpale) ;
			salle190916jeudi0800InS1F1.add(saInJade) ;	
		}
		
	// -------------------------- Creneau --------------------------------------------
		
		public static List<Creneau> selectCreneau (String... id)
		{

			List<Creneau> liste ;
			
			if (id.length != 0)
			{
				liste =  DaoTest.CRENEAUX.stream().filter(c -> c.getDebsemc().equals(id[0]) && 
						c.getJourc().equals(id[1]) && 
						c.getHeuredc().equals(id[2]) &&
						c.getGrpc().getGrpc().equals(id[3])).collect(Collectors.toList()) ;
			}
			else
			{
				liste = new ArrayList<>(DaoTest.CRENEAUX) ;
			}
			return liste ;	
		}
		
		public static void insertCreneau(Creneau c)
		{
			DaoTest.CRENEAUX.add(c) ;
		}
		
		public static void updateCreneau(Creneau c)
		{
			List<Creneau> liste = DaoTest.selectCreneau(c.getDebsemc(), c.getJourc(), c.getHeuredc(), c.getGrpc().getGrpc()) ;
			Creneau d = liste.get(0) ;
			d.setHeurefc(c.getHeurefc());
			d.setTypec(c.getTypec());
			d.setMatc(c.getMatc());
			d.setEnsc(c.getEnsc());
			d.setSalC(c.getSalC());
		}	

		public static void deleteCreneau(Creneau c)
		{
			DaoTest.CRENEAUX.remove(c) ;
		}
		
	// -------------------------- Enseignant ----------------------------------------	
		
		public static List<Enseignant> selectEnseignant (String... id)
		{
			List<Enseignant> liste ;
			if (id.length != 0)
			{
				liste =  DaoTest.ENSEIGNANTS.stream().filter(e -> e.getId_enseignant().equals(id[0])).collect(Collectors.toList()) ;
			}
			else
			{
				liste = new ArrayList<>(DaoTest.ENSEIGNANTS) ;
			}
			return liste ;	
		}	
		
		public static void insertEnseignant(Enseignant e)
		{
			DaoTest.ENSEIGNANTS.add(e) ;
		}
		
		public static void updateEnseignant(Enseignant e)
		{
			List<Enseignant> liste = DaoTest.selectEnseignant(e.getId_enseignant()) ;
			Enseignant d = liste.get(0) ;
			d.setNbhdisp(e.getNbhdisp());
			d.setNom(e.getNom());
			d.setPrenom(e.getPrenom());
			d.setGrade(e.getGrade());
		}	
		
		public static void deleteEnseignant(Enseignant e)
		{
			DaoTest.ENSEIGNANTS.remove(e) ;
		}	
		
	// -------------------------- Formation -----------------------------------------
		
		public static List<Formation> selectFormation (String... id)
		{
			List<Formation> liste ;
			if (id.length != 0)
			{
				liste =  DaoTest.FORMATIONS.stream().filter(f -> f.getIdfor().equals(id[0])).collect(Collectors.toList()) ;
			}
			else
			{
				liste = new ArrayList<>(DaoTest.FORMATIONS) ;
			}
			return liste ;	
		}
		
		public static void insertFormation(Formation f)
		{
			DaoTest.FORMATIONS.add(f) ;
		}
		
		public static void updateFormation(Formation f)
		{
			List<Formation> liste = DaoTest.selectFormation(f.getIdfor()) ;
			Formation d = liste.get(0) ;
			d.setIdfor(f.getIdfor());
			d.setLibf(f.getLibf());
			d.setNbgrc(f.getNbgrc());
			d.setNbgrtd(f.getNbgrtd());
			d.setNbgrtp(f.getNbgrtp());
		}		
		
		public static void deleteFormation(Formation f)
		{
			DaoTest.FORMATIONS.remove(f) ;
		}
		
	// -------------------------- Groupe --------------------------------------------	
		
		public static List<Groupe> selectGroupe (String... id)
		{
			List<Groupe> liste ;
			if (id.length != 0)
			{
				liste =  DaoTest.GROUPES.stream().filter(g -> g.getGrpc().equals(id[0])).collect(Collectors.toList()) ;
			}
			else
			{
				liste = new ArrayList<>(DaoTest.GROUPES) ;
			}
			return liste ;	
		}
		
		public static void insertGroupe(Groupe g)
		{
			DaoTest.GROUPES.add(g) ;
		}
		
		public static void updateGoupe(Groupe g)
		{
			List<Groupe> liste = DaoTest.selectGroupe(g.getGrpc()) ;
			Groupe d = liste.get(0) ;
			d.setGrpc(g.getGrpc());
			d.setAnnee(g.getAnnee());
			d.setAnneec(g.getAnneec());
			d.setEff(g.getEff());
		}
		
		public static void deleteGroupe(Groupe g)
		{
			DaoTest.GROUPES.remove(g) ;
		}	
		
	// -------------------------- Mat -----------------------------------------------
		
		public static List<Mat> selectMat (String... id)
		{
			List<Mat> liste ;
			if (id.length != 0)
			{
				liste =  DaoTest.MATS.stream().filter(m -> m.getMatc().equals(id[0])).collect(Collectors.toList()) ;
			}
			else
			{
				liste = new ArrayList<>(DaoTest.MATS) ;
			}
			return liste ;	
		}
		
		public static void insertMat(Mat m)
		{
			DaoTest.MATS.add(m) ;
		}
		
		public static void updateMat(Mat m)
		{
			List<Mat> liste = DaoTest.selectMat(m.getMatc()) ;
			Mat d = liste.get(0) ;
			d.setMatc(m.getMatc());
			d.setIntc(m.getIntc());
		}
		
		public static void deleteMat(Mat m)
		{
			DaoTest.MATS.remove(m) ;
		}
		
	// -------------------------- Salle ---------------------------------------------
		
		public static List<Salle> selectSalle (String... id)
		{
			List<Salle> liste ;
			if (id.length != 0)
			{
				liste =  DaoTest.SALLES.stream().filter(s -> s.getNsalle().equals(id[0])).collect(Collectors.toList()) ;
			}
			else
			{
				liste = new ArrayList<>(DaoTest.SALLES) ;
			}
			return liste ;	
		}	
		
		public static void insertSalle (Salle s)
		{
			DaoTest.SALLES.add(s) ;
		}	
		
		public static void updateSalle(Salle s)
		{
			List<Salle> liste = DaoTest.selectSalle(s.getNsalle()) ;
			Salle d = liste.get(0) ;
			d.setCapacite(s.getCapacite());
			d.setNsalle(s.getNsalle());
			d.setTsal(s.getTsal());
		}
		
		public static void deleteSalle(Salle s)
		{
			DaoTest.SALLES.remove(s) ;
		}	
		
	// -------------------------- Statut---------------------------------------------
		
		public static List<Statut> selectStatut (String... id)
		{
			List<Statut> liste ;
			if (id.length != 0)
			{
				liste =  DaoTest.STATUTS.stream().filter(s -> s.getGrade().equals(id[0])).collect(Collectors.toList()) ;
			}
			else
			{
				liste = new ArrayList<>(DaoTest.STATUTS) ;
			}
			return liste ;	
		}
		
		public static void insertStatut (Statut s)
		{
			DaoTest.STATUTS.add(s) ;
		}
		
		public static void updateStatut(Statut s)
		{
			List<Statut> liste = DaoTest.selectStatut(s.getGrade()) ;
			Statut d = liste.get(0) ;
			d.setGrade(s.getGrade());
			d.setNbheurst(s.getNbheurst());
		}		
		
		public static void deleteStatut(Statut s)
		{
			DaoTest.STATUTS.remove(s) ;
		}
	}



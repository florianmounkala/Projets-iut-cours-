package DAO;
import java.sql.Connection;
import java.sql.SQLException;

import oracle.jdbc.datasource.impl.OracleDataSource;

public class CictOracleDataSource extends OracleDataSource{

	public CictOracleDataSource() throws SQLException {
		this.setURL("jdbc:oracle:thin:@telline.univ-tlse3.fr:1521:etupre");
		this.setUser("msd4555a") ;
		this.setPassword("diegomb972") ;
	}
	
	public static void main(String[] args) throws SQLException{
		CictOracleDataSource bd = new CictOracleDataSource();
		Connection cn = bd.getConnection() ;
		System.out.println("Connexion �tablie...") ;
		cn.close() ;
	}
	
	
	
}

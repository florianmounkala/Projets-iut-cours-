package DAO;
import modele.Statut;
public class DAO_Statut implements Dao<Statut>{

	@Override
	public void select(Statut element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Statut element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Statut element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(Statut element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Statut findByld(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Statut findAll() {
		// TODO Auto-generated method stub
		return null;
	}



	
}

package DAO;
import modele.Creneau;

public class DAO_Creneau implements Dao<Creneau>{



	@Override
	public void update(Creneau element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Creneau element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(Creneau element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Creneau findByld(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Creneau findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void select(Creneau element) {
		// TODO Auto-generated method stub
		
	}


	
	
	
	
}

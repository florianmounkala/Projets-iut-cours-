package DAO;
import modele.Enseignant;

public class DAO_Enseignant implements Dao<Enseignant>{

	@Override
	public void select(Enseignant element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Enseignant element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Enseignant element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(Enseignant element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Enseignant findByld(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Enseignant findAll() {
		// TODO Auto-generated method stub
		return null;
	}


}

package DAO;

public interface Dao<T> {
	
	public void select(T element);
	public void update(T element);
	public void delete(T element);
	public void insert(T element);
	public T findByld(String id);
	public T findAll();
	
}

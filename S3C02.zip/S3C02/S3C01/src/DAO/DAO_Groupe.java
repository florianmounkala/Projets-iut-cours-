package DAO;
import modele.Groupe;

public class DAO_Groupe implements Dao<Groupe> {

	@Override
	public void select(Groupe element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Groupe element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Groupe element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(Groupe element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Groupe findByld(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Groupe findAll() {
		// TODO Auto-generated method stub
		return null;
	}


	

}

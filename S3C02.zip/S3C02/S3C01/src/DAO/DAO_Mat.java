package DAO;
import modele.Mat;

public class DAO_Mat implements Dao<Mat>{

	@Override
	public void select(Mat element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Mat element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Mat element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(Mat element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Mat findByld(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Mat findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	

	

}

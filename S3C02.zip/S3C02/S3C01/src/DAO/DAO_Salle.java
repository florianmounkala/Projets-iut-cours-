package DAO;
import modele.Salle;

public class DAO_Salle implements Dao<Salle>{

	@Override
	public void select(Salle element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Salle element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Salle element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(Salle element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Salle findByld(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Salle findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	


}

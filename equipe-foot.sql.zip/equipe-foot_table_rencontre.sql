
-- --------------------------------------------------------

--
-- Structure de la table `rencontre`
--

CREATE TABLE `rencontre` (
  `Id_Rencontre` int(11) NOT NULL,
  `heure_du_Match` time DEFAULT NULL,
  `Score_de_l_equipe_adverse` varchar(50) DEFAULT NULL,
  `lieu_` varchar(50) DEFAULT NULL,
  `nom_de_l_equipe_adverse` varchar(50) DEFAULT NULL,
  `Score_de_notre_equipe` int(11) DEFAULT NULL,
  `Date_du_match` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `rencontre`
--

INSERT INTO `rencontre` (`Id_Rencontre`, `heure_du_Match`, `Score_de_l_equipe_adverse`, `lieu_`, `nom_de_l_equipe_adverse`, `Score_de_notre_equipe`, `Date_du_match`) VALUES
(1, '16:00:00', '0', 'Quatar', 'Maroc', 2, '2022-12-13'),
(2, '20:00:00', '0', 'Paris', 'Angleterre', 1, '2012-12-03');

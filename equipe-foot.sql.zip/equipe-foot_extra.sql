
--
-- Index pour les tables déchargées
--

--
-- Index pour la table `joueurs`
--
ALTER TABLE `joueurs`
  ADD PRIMARY KEY (`numero_de_licence`),
  ADD KEY `Id_Rencontre` (`Id_Rencontre`);

--
-- Index pour la table `participent`
--
ALTER TABLE `participent`
  ADD PRIMARY KEY (`numero_de_licence`,`Id_Rencontre`),
  ADD KEY `Id_Rencontre` (`Id_Rencontre`);

--
-- Index pour la table `rencontre`
--
ALTER TABLE `rencontre`
  ADD PRIMARY KEY (`Id_Rencontre`);

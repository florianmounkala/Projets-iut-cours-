
-- --------------------------------------------------------

--
-- Structure de la table `participent`
--

CREATE TABLE `participent` (
  `numero_de_licence` int(11) NOT NULL,
  `Id_Rencontre` int(11) NOT NULL,
  `Position` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `participent`
--

INSERT INTO `participent` (`numero_de_licence`, `Id_Rencontre`, `Position`) VALUES
(1, 1, ''),
(3, 1, '');

==>README.txt<==

# Le code source python se trouve dans le dossier "sous-titre" 

# Les logs du compte debian et root est : user:"yanis", motdepasse:"1234"

# Les logs de PhpMyAdmin : user:"root", motdepasse:"1234"

# WaveWatcher by AFRITE Yanis & MOUNKALA Florian
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 26 11:49:27 2023

@author: flomr
"""

import fonction_filtres as ff

# Exemple d'utilisation
def filtrage_mots_interdits_zip(fichier_json, chemin_fichier_zip):
    liste_nom_fichier = ff.obtenir_noms_fichiers_zip(chemin_fichier_zip)
    i = 0
    while  i <len(liste_nom_fichier) :
        liste_ligne = ff.obtenir_mots_fichiers(chemin_fichier_zip, liste_nom_fichier[i])
        liste_mot = ff.convertisseur_phrase_mot(liste_ligne)
        liste_mot_filtre = ff.obtenir_mots_filtes(liste_mot, fichier_json)
        print( liste_nom_fichier[i] , len(liste_mot_filtre)) 
        print(ff.calculate_tfidf(liste_mot_filtre))
        i = i+1

# Exemple d'utilisation
fichier_json = "mots-interdits.json"
chemin_fichier_zip = '24s01VF.zip'
fichier_srt = 'whitechapels01e01VF.srt'



def filtrage_mots_interdits(liste_mots_interdits, nom_fichier_srt):
    mots_extraits = ff.extraire_mots_de_srt(nom_fichier_srt)
    # Remplacez par le chemin de votre fichier JSON
    valeurs_interdites = ff.extraire_valeurs_json(liste_mots_interdits)

    liste_filtre = []
    for mot in mots_extraits:
        mot_majuscules = ff.detecter_et_remplacer_majuscule(mot)
        if ff.filtrage(mot_majuscules, valeurs_interdites) is not None:
            liste_filtre.append(mot_majuscules)
    print(len(liste_filtre))
    return ff.calculate_tfidf(liste_filtre)

x =filtrage_mots_interdits(fichier_json,fichier_srt)
y = []
z = 0
while z <10 :
    y.append(x[z])
    z = z+1
print (y)
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 10 17:29:52 2023

@author: flomr
"""

import pymongo

# Établir une connexion à la base de données MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017/")
database = client["nom_de_la_base_de_données"]
collection_source = database["nom_de_la_collection_source"]
collection_destination = database["nom_de_la_collection_destination"]

# Récupérer le document souhaité de la collection source
document = collection_source.find_one({"_id": ObjectId("id_du_document")})

# Récupérer la variable à modifier du document
variable = document["nom_de_la_variable"]

# Modifier la variable selon les besoins
nouvelle_variable = variable + " (modifié)"

# Stocker la nouvelle variable dans la collection destination
nouveau_document = {
    "_id": ObjectId(),
    "nouvelle_variable": nouvelle_variable
}
collection_destination.insert_one(nouveau_document)

# Fermer la connexion à la base de données
client.close()
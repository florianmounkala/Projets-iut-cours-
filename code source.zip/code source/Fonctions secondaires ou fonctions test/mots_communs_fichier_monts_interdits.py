# -*- coding: utf-8 -*-
"""
Created on Tue Oct 10 12:16:46 2023

@author: flomr
"""

"""importations """
import re
from nltk.corpus import stopwords


def est_mot_vide(mot):
    mots_vides_fr = set(stopwords.words("french"))
    return mot in mots_vides_fr

def trouver_entier_dans_chaine(chaine):
    # Utilise une expression régulière pour trouver un entier dans la chaîne
    match = re.search(r'\d+', chaine)

    if match:
        return True  # Convertit la chaîne en entier
    else:
        # Si aucun entier n'est trouvé, renvoie None
        return False

def filtrage(mot):
    liste_mots_interdits = extraire_valeurs_json('stop_words.json')
    mot_min = mot.lower()
    mots_vides_eng = set(stopwords.words("english"))
    mots_vides_fr = set(stopwords.words("french"))
    mot_eng = mot_min in mots_vides_eng
    mot_fr = mot_min in mots_vides_fr    
    compteur_mot_interdit = 1
    x =  0
    if trouver_entier_dans_chaine(mot_min) == True :
        x = x+1    
    for compteur_mot_interdit in range(len(liste_mots_interdits)):
        if mot_min == liste_mots_interdits[compteur_mot_interdit]:
            x = x+1
    if mot_min == '':
        x = x+1
    if mot_eng == True :
        x=x+1
    if mot_fr == True :
        x = x+1
    if x == 0 :
        return mot_min
    else :
        return None

# Exemple d'utilisation
mot = "Voiture"
liste_test = ["ok","Elle","tu","je"]
resultat = filtrage(mot , liste_test)
print(resultat)



import fonction_filtres as ff

def filtrage(mot):
    if '.' in mot:
        mot_sans_point = mot.replace('.', '')
        mot_min = mot_sans_point.lower()
    else:
        mot_min = mot.lower() 
    x =  0
    
    if ff.trouver_entier_dans_chaine(mot_min) == True :
        x = x+1    
    if mot_min == '':
        x = x+1
    if mot_min in ff.liste_mots_interdits :
        x = x+1
    
    if x == 0 :
        return mot_min
    else :
        return None
    
    
print(filtrage("Ok"))
print(filtrage("Voiture"))
print(filtrage("OK."))
print(filtrage("une"))
print(filtrage("Elles."))
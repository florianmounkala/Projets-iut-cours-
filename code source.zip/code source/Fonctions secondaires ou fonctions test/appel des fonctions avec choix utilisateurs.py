# -*- coding: utf-8 -*-
"""
Created on Tue Sep 26 09:09:47 2023

@author: flomr
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Sep 12 18:43:18 2023

@author: flomr
"""

import os
import fonction_filtres as ff

#Création des listes de filtrage
fichier_json = "mots-interdits.json" 
fichier_json_eng = "stop_words_english.json"
valeurs_interdites_eng = ff.extraire_valeurs_json(fichier_json_eng)
valeurs_interdites = ff.extraire_valeurs_json(fichier_json)

# Création des compteurs 
nombre_de_zip = 0
nombre_de_srt = 0
nombre_erreurs = 0
nombre_vf = 0
nombre_vo = 0

#Définition de la fonction d'extraction ZIP
def filtrage_mots_interdits_zip(fichier_json, chemin_fichier_zip):
    liste_nom_fichier = ff.obtenir_noms_fichiers_zip(chemin_fichier_zip)
    i = 0
    x = len(liste_nom_fichier)
    while i <= x :
        liste_ligne = ff.obtenir_mots_fichiers(chemin_fichier_zip, liste_nom_fichier[i])
        liste_mot = ff.convertisseur_phrase_mot(liste_ligne)
        liste_mot_filtre = ff.obtenir_mots_filtes(liste_mot, fichier_json)
        return liste_mot_filtre
        i = i+1


#Définition de la fonction d'extraction SRT

def filtrage_mots_interdits(liste_mots_interdits, nom_fichier_srt):
    mots_extraits = ff.extraire_mots_de_srt(nom_fichier_srt)
    # Remplacez par le chemin de votre fichier JSON
    valeurs_interdites = ff.extraire_valeurs_json(liste_mots_interdits)

    liste_filtre = []
    for mot in mots_extraits:
        mot_majuscules = ff.detecter_et_remplacer_majuscule(mot)
        if ff.filtrage(mot_majuscules, valeurs_interdites) is not None:
            liste_filtre.append(mot_majuscules)
        return liste_filtre
     
# Extraction de la liste des séries (noms des dossiers contenant les fichiers audios)
liste_dossiers = ff.extraire_valeurs_json('liste_des_fichier.json')

def list_files(directory):
    files = []
    for dirpath, dirnames, filenames in os.walk(directory):
        for filename in filenames:
            files.append(os.path.join(dirpath, filename))
    return files

# Appel de la fonction pour lister les fichiers du dossier choisir ( liste des fichiers d'un dossier)
choix = None
i = 0
choix = input("Faites un choix (1 suite, 2 reesayer ou 3 anuler) : ")
# Boucle tant que le choix n'est pas valide
while choix not in [ "3"]:
        if choix == "1":
            i = i+1
        liste_fichiers = list_files(liste_dossiers[i])
        
        for fichier in liste_fichiers :
            
            #détermination du type de fichier 
            if ff.determine_file_type(fichier) == 'ZIP' :
                nombre_de_zip = nombre_de_zip+1
                
                #détermination de la langue du fichier
                if ff.detecter_sous_chaine(fichier) == 'English' :
                    
                    #Ajout du compteur
                    nombre_vo = nombre_vo +1
                    
                    #Extraction des mots
                    print("FICHIER ZIP :",fichier)
                    print(filtrage_mots_interdits_zip(fichier_json_eng, fichier))
                        
                elif ff.detecter_sous_chaine(fichier) == 'french':
                    
                    #Ajout au compteur
                    nombre_vf = nombre_vf +1
                    
                    #Extraction des mots
                    print("FICHIER ZIP :",fichier)
                    print(filtrage_mots_interdits_zip(fichier_json, fichier))
                else:
                    print(fichier)
            
            else : 
                print(fichier)
                nombre_erreurs = nombre_erreurs +1
                
        choix = input("Faites un choix (1 suite, 2 reesayer ou 3 anuler) : ")
#Affichage des statistiques
print("le nombre de fichiers zip est de :", nombre_de_zip)
print("le nombre de fichiers srt direct est de :", nombre_de_srt)
print("le nombre d'erreurs est de :",nombre_erreurs)
print("le nombre de VF est de :",nombre_vf)
print("le nombre de VO est de :",nombre_vo)
print(nombre_vo + nombre_vf , nombre_de_zip + nombre_de_srt)

# -*- coding: utf-8 -*-
"""
Created on Tue Sep 26 08:28:06 2023

@author: flomr
"""


from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

def calculate_tfidf(word_list):
    text = ' '.join(word_list)
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform([text])
    scores = tfidf_matrix.toarray()[0]
    return np.array(list(zip(word_list, scores)), dtype=object)

word_list = ["chat", "chien", "oiseau", "chat", "souris", "chien"]
tfidf_scores = calculate_tfidf(word_list)

print(tfidf_scores)
public class Application {

	public static void main(String[] args) {
		Personne[] listePersonnes = { new Personne("S�des", "Florence"),
									  new Personne("Viallet", "Fabienne"),
									  new Personne("Julien", "Christine"),
									  new Personne("Percebois", "Christian"),
									  new Personne("Leblanc", "Herv�")};
		
		Observer etatCivilToulouse = new ObserverEtatCivil();
		Observer laPosteToulouse = new ObserverLaPoste();
		
		for (Personne p : listePersonnes) {
			p.attach(etatCivilToulouse);
			p.attach(laPosteToulouse);
		}
			
		listePersonnes[3].ajoutPr�nom("Augustin");
		listePersonnes[4].ajoutPr�nom("Just");
		listePersonnes[4].setNom("Lerouge");
	}

}

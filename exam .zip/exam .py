#!/usr/bin/env python
# coding: utf-8

# In[13]:


##Exercice 1: 
## j'utilise la formule matmul de numpy pour pouvoir obtenir la mesure initiale de µ après
## chaque évolution du système
import numpy as np 
M = np.array([[0.1,0.7,0,0.1],[0.2,0,0.8,0],[0,0.3,0.6,0.1],[0.2,0.1,0.5,0.2]],dtype=float)
x = np.array([0.1,0.7,0,0.1],dtype=float)

def mesure(M, µ):
  for i in range(4):
    µ = np.matmul(M, µ)
  return µ


print (mesure(M,x))


## Variante de la fontion renvoyant chaque évolution du systéme

def mesure_détaillé(M, µ):
  for i in range(4):
    µ = np.matmul(M, µ)
    print (µ)
  return µ

print (mesure_détaillé(M,x))


# In[23]:


##Exercice 2
import numpy as np 
import matplotlib.pyplot as plt
u = 1.5 
b = 3 

x =np.random.gumbel(u,b,10000)

y = np.linspace(u - 5 * b, u + 5 * b, 1000)
z = (1/b) * np.exp(-((y - u) / b) - np.exp(-((y - u) / b)))

plt.hist(x, 50, density=1, histtype='bar')
plt.plot(y,z)
plt.xlabel('Valeur')
plt.ylabel('Probabilite')
plt.title("Histogramme d'une loi de Gumber de paramètres µ = 1.5 et β = 3  ")
plt.show()


# In[27]:


##Exercice 3 

def resoudre_systeme(A, b , t):
    if t := 1
     x = np.linalg.solve(A, b)
     pi = x / np.sum(x)
     return x, pi
    else 
      x = np.linalg.solve(A, b)
      return x


# In[ ]:





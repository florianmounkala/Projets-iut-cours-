# -*- coding: utf-8 -*-
"""
Created on Tue Oct 10 17:47:54 2023

@author: flomr
"""

from nltk.corpus import stopwords

# Obtenir la liste des fichiers du module stopwords
fichiers_stopwords= stopwords.words("english")
fichiers_stopwordsr = stopwords.words("french")

# Afficher la liste des fichiers
for fichier in fichiers_stopwordsr:
    print(fichier)
    
CREATE TABLE SAE_Equipement(
   id_equipement                NUMBER(10),
   date_dernière_révision       DATE,
   nom                          VARCHAR2(50)  constraint NN_SAE_Equipement_nom NOT NULL,
   date_de_validité_révision    DATE,
   constraint PK_SAE_Equipement PRIMARY KEY(id_equipement),
   constraint CK_SAE_Equipement_date CHECK (date_dernière_révision <  date_de_validité_révision)
);

CREATE TABLE SAE_Locataire(
   id_locataire             NUMBER(10),
   nom                      VARCHAR2(50)         constraint NN_SAE_Locataire_nom NOT NULL,
   prenom                   VARCHAR2(50)         constraint NN_SAE_Locataire_prenom NOT NULL,
   adresse_domicil_société  VARCHAR2(150) ,
   E_mail                   VARCHAR2(50) ,
   Tél                      CHAR(10)             constraint NN_SAE_Locataire_Tél  NOT NULL,
   constraint PK_SAE_Locataire PRIMARY KEY(id_locataire)
);

CREATE TABLE SAE_Batiment(
   n_batiment       NUMBER(3),
   nb_logement      NUMBER(10),
   code_postal      CHAR(5),
   nb_étage         VARCHAR2(50) ,
   rue              VARCHAR2(100) constraint NN_SAE_Batiment_rue NOT NULL,
   ville            VARCHAR2(50) constraint NN_SAE_Batiment_ville NOT NULL,
   constraint PK_SAE_Batiment PRIMARY KEY(n_batiment)
);

CREATE TABLE sae_type_charges(
    Id_Type_Charges NUMBER(10),
    typeC VARCHAR2(50) ,
    PRIMARY KEY(Id_Type_Charges)
);

CREATE TABLE SAE_Charges(
   réf              VARCHAR2(10) ,
   consommation     decimal(10,2),
   unité            varchar2(5),
   Prix_unitaire    decimal(19,4),
   Abonnement       decimal(19,4),
   Date_charges     date,
   Id_type_charges  number,
   constraint PK_SAE_Charges PRIMARY KEY(réf),
   constraint FK_SAE_Charges_Id_type_charges FOREIGN KEY(Id_type_charges) REFERENCES SAE_Type_Charges(Id_type_charges)
);

CREATE TABLE SAE_Entreprise(
   n_SIREN      CHAR(9) ,
   Nom          VARCHAR2(50) constraint NN_SAE_Entreprise_Nom NOT NULL,
   Adresse      VARCHAR2(50) ,
   CP           VARCHAR2(50) ,
   IBAN         CHAR(34) constraint NN_SAE_Entreprise_IBAN NOT NULL,
   adresse_mail VARCHAR2(50) ,
   Tél          CHAR(10) ,
   constraint PK_SAE_Entreprise PRIMARY KEY(n_SIREN)
);

CREATE TABLE SAE_Type_facture(
   Id_Type_facture  NUMBER(10),
   typeF            VARCHAR2(50) constraint NN_SAE_Type_facture_typeF  NOT NULL,
   constraint PK_SAE_Type_facture PRIMARY KEY(Id_Type_facture)
);

CREATE TABLE SAE_Logement(
   n_batiment       NUMBER(3),
   n_logement       NUMBER(10),
   localisation     CLOB,
   typeLogement     VARCHAR2(50)            constraint NN_SAE_Logement_typeLogement  NOT NULL,
   régime_juridique VARCHAR2(50) ,
   balcon           NUMBER(1) DEFAULT ('0'),
   période_de_construction      DATE        constraint NN_SAE_Logement_période_const NOT NULL,
   surface                      NUMBER(6,2) constraint NN_SAE_Logement_surface NOT NULL,
   nb_pièces        NUMBER(10),
   garage           NUMBER(1) DEFAULT ('0'),
   jardin           NUMBER(1) DEFAULT ('0'),
   étage            VARCHAR2(50) ,
   porte            NUMBER(3) ,
   réf_EDL          NUMBER(10),
   Base_loyer_M     NUMBER(19,4),
   charges_fixes    NUMBER(19,4),
   ICC              decimal(3, 2)               constraint NN_SAE_Logement_ICC NOT NULL,
   constraint PK_SAE_Logement PRIMARY KEY(n_batiment, n_logement),
   constraint FK_SAE_Logement_Nbat FOREIGN KEY(n_batiment) REFERENCES SAE_Batiment(n_batiment)
);

CREATE TABLE SAE_Facture(
   référence             CHAR(10) ,
   référence_du_paiement VARCHAR2(50) ,
   date_facture         DATE,
   charges_dues         NUMBER(6,2)  ,
   charges_régularisés  NUMBER(6,2)  ,
   Date_de_paiement     DATE,
   type_de_paiement     VARCHAR2(50) ,
   aide                 NUMBER(1),
   montant_de_l_aide    NUMBER(10),
   Prix                 NUMBER(19,4),
   Id_Type_facture      NUMBER(10),
   n_SIREN              CHAR(9),
   description          VARCHAR(50),
   constraint PK_SAE_Facture PRIMARY KEY(référence),
   constraint FK_SAE_Facture_Id_Type_facture FOREIGN KEY(Id_Type_facture) REFERENCES SAE_Type_facture(Id_Type_facture),
   constraint FK_SAE_Facture_n_SIREN FOREIGN KEY(n_SIREN) REFERENCES SAE_Entreprise(n_SIREN)
);

CREATE TABLE SAE_Fiche_diagnostic(
   Réf              VARCHAR2(50) ,
   Amiante          NUMBER(1) DEFAULT ('0'),
   Date_Amiante     DATE,
   Plomb            NUMBER(1) DEFAULT ('0'),
   Date_plomb       DATE,
   date_diag_ERP    DATE,
   Date_ERP_de_validité     DATE,
   Date_diag_DPE            DATE,
   Date_limite_validité_DPE DATE,
   n_batiment       NUMBER(3),
   n_logement       NUMBER(10),
   constraint PK_SAE_FicheDiagnostic PRIMARY KEY(Réf),
   constraint FK_SaeFicheDiagnostic_NbatNlog FOREIGN KEY(n_batiment, n_logement) REFERENCES SAE_Logement(n_batiment, n_logement),
   CONSTRAINT CK_SAE_FicheDiagnostic_dateERP CHECK (date_diag_ERP <  Date_ERP_de_validité),
   CONSTRAINT CK_SAE_FicheDiagnostic_dateDPE CHECK (Date_diag_DPE <  Date_limite_validité_DPE)
);

CREATE TABLE SAE_Contrat_bail(
   id_bail          NUMBER(10),
   date_début       DATE constraint NN_SAE_Contrat_bail_date_début NOT NULL,
   date_fin         DATE,
   frais_d_agence   NUMBER(19,4),
   Caution          NUMBER(19,4) constraint NN_SAE_Contrat_bail_Caution NOT NULL,
   nb_locataire     NUMBER(10),
   n_batiment       NUMBER(3),
   n_logement       NUMBER(10),
   constraint PK_SAE_Contrat_bail PRIMARY KEY(id_bail),
   constraint FK_SAE_Contrat_bail_Nbat_Nlog FOREIGN KEY(n_batiment, n_logement) REFERENCES SAE_Logement(n_batiment, n_logement),
   constraint CK_SAE_Contrat_bail_date_D_F CHECK (date_début <  date_fin)
);

CREATE TABLE SAE_signer(
   id_bail      NUMBER(10),
   id_locataire NUMBER(10),
   constraint PK_SAE_signer PRIMARY KEY(id_bail, id_locataire),
   constraint FK_SAE_signer_id_bail FOREIGN KEY(id_bail) REFERENCES SAE_Contrat_bail(id_bail),
   constraint FK_SAE_signer_id_locataire FOREIGN KEY(id_locataire) REFERENCES SAE_Locataire(id_locataire)
);

CREATE TABLE SAE_Posseder(
   id_equipement NUMBER(10),
   n_batiment    NUMBER(3),
   n_logement    NUMBER(10),
   constraint PK_SAE_Posseder PRIMARY KEY(id_equipement, n_batiment, n_logement),
   constraint FK_SAE_Posseder_id_equipement FOREIGN KEY(id_equipement) REFERENCES SAE_Equipement(id_equipement),
   constraint FK_SAE_Posseder_Nbat_Nlog FOREIGN KEY(n_batiment, n_logement) REFERENCES SAE_Logement(n_batiment, n_logement)
);

CREATE TABLE SAE_lier_logement(
   référence        CHAR(10)            NOT NULL,
   n_batiment       NUMBER(3)           NOT NULL,
   n_logement       NUMBER(10)          NOT NULL,
   constraint FK_SAE_lier_logement_référence FOREIGN KEY(référence) REFERENCES SAE_Facture(référence),
   constraint FK_SAE_lier_logement_Nbat_Nlog FOREIGN KEY(n_batiment, n_logement) REFERENCES SAE_Logement(n_batiment, n_logement)
);

CREATE TABLE SAE_associer(
   n_batiment   NUMBER(3),
   n_logement   NUMBER(10),
   réf          VARCHAR2(10),
   quotité      VARCHAR2(50),
   constraint PK_SAE_associer PRIMARY KEY(n_batiment, n_logement, réf),
   constraint FK_SAE_associer_Nlog_Nbat FOREIGN KEY(n_batiment, n_logement) REFERENCES SAE_Logement(n_batiment, n_logement),
   constraint FK_SAE_associer_réf FOREIGN KEY(réf) REFERENCES SAE_Charges(réf)
);

CREATE TABLE SAE_correspondre(
   référence    CHAR(10),
   réf          VARCHAR2(10),
   Paiement     NUMBER(11,2),
   constraint PK_SAE_correspondre PRIMARY KEY(référence, réf),
   constraint FK_SAE_correspondre_référence FOREIGN KEY(référence) REFERENCES SAE_Facture(référence),
   constraint FK_SAE_correspondre_réf FOREIGN KEY(réf) REFERENCES SAE_Charges(réf)
);


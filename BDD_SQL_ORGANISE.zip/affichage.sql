-- affichage des données de chaque table

select * from sae_Locataire;
select * from sae_batiment;
select * from sae_logement;
select * from sae_facture;
select * from sae_type_facture;
select * from sae_type_charges;
select * from sae_entreprise;
select * from sae_charges;
select * from sae_contrat_bail;
select * from sae_fiche_diagnostic;
select * from sae_equipement;
select * from sae_posseder;
select * from sae_associer;
select * from sae_signer;
select * from sae_correspondre;

commit;
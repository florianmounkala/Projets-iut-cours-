-- test de l'insert locataire
create or replace trigger TRIGGER_LOC
 after 
    insert on sae_locataire
 begin
    dbms_output.put_line('OK');
 end TRIGGER_LOC;

-- test de l'update locataire 
create or replace trigger TRIGGER_LOC2
 after  
    update on sae_locataire
   begin 
      dbms_output.put_line('OK');
   end TRIGGER_LOC2; 

-- test de l'update loyer 
create or replace trigger UPDATE_LOYER
 after  
    update of charges_fixes on sae_logement
   begin 
      dbms_output.put_line('OK');
end UPDATE_LOYER; 

-- test de l'update locataire nom
create or replace trigger UPDATELOC_N
after update of nom  on sae_locataire
for each row
begin
   dbms_output.put_line('Nouveau nom: ' || :new.nom);
   dbms_output.put_line('Ancien nom: ' || :old.nom);
end;

-- test de l'update locataire prenom
create or replace trigger UPDATELOC_P
after update of prenom on sae_locataire
for each row
begin
   dbms_output.put_line('Nouveau prénom: ' || :new.prenom);
   dbms_output.put_line('Ancien prénom: ' || :old.prenom);
end;
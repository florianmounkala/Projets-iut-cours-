-- suppression si jamais au cas où

drop table SAE_associer cascade constraint;
drop table sae_batiment cascade constraint; 
drop table SAE_charges cascade constraint; 
drop table SAE_contrat_bail cascade constraint; 
drop table sae_correspondre cascade constraint; 
drop table SAE_entreprise cascade constraint; 
drop table sae_equipement cascade constraint; 
drop table sae_facture cascade constraint; 
drop table SAE_fiche_diagnostic cascade constraint; 
drop table SAE_lier_logement cascade constraint; 
drop table SAE_locataire cascade constraint; 
drop table sae_logement cascade constraint;
drop table sae_posseder cascade constraint; 
drop table sae_signer cascade constraint; 
drop table sae_type_facture cascade constraint; 
drop table sae_type_charges cascade constraint; 


-- ajouter un logement
    create or replace procedure AJOUTER_LOGEMENT(numBat sae_logement.n_batiment%type, numLog sae_logement.n_logement%type, 
    localisation sae_logement.localisation%type, typelogement sae_logement.typelogement%type, 
    régime_juridique sae_logement.régime_juridique%type, 
    balcon sae_logement.balcon%type, période_de_construction sae_logement.période_de_construction%type, 
    surface sae_logement.surface%type, nb_pièces sae_logement.nb_pièces%type, garage sae_logement.garage%type, 
    jardin sae_logement.jardin%type, étage sae_logement.étage%type, porte sae_logement.porte%type, 
    réf_edl sae_logement.réf_edl%type, base_loyer_m sae_logement.base_loyer_m%type,charges_fixes sae_logement.charges_fixes%type, icc sae_logement.ICC%type
    ) is
    begin
        insert into sae_logement(n_batiment, n_logement, localisation, typelogement, 
        régime_juridique, balcon, période_de_construction, surface, nb_pièces, garage, 
        jardin, étage, porte, réf_edl, base_loyer_m, charges_fixes, ICC) 
        values 
        (numBat, numLog, localisation, typelogement,
        régime_juridique, balcon, période_de_construction, surface, nb_pièces, garage, jardin, étage, porte, réf_edl,
        base_loyer_m, charges_fixes, icc);
    end;
    
    
-- modifier le loyer d'un logement donnée
    create or replace procedure MODIFIER_LOYER_LOGEMENT(numBat sae_logement.n_batiment%type, numLog sae_logement.n_logement%type, base_loyer sae_logement.base_loyer_m%type)
    is
    begin
        update sae_logement
        set base_loyer_m = base_loyer
        where n_batiment = numBat 
        and n_logement = numLog;
    end;
    
    
    
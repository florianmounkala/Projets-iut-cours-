
-- logement d'un batiment
create or replace function Logements_d_un_batiment ( batiment_x number )return  SAE_LOGEMENT.N_LOGEMENT%TYPE as LL SAE_LOGEMENT.N_LOGEMENT%TYPE;
begin
    select SAE_LOGEMENT.N_LOGEMENT into LL
    from SAE_LOGEMENT
    where SAE_LOGEMENT.N_BATIMENT = batiment_x;
    return LL;
end Logements_d_un_batiment;


-- fonction logement_inhabitées
create or replace function Logement_inhabitées ( batiment_b number , date_a date)return SAE_LOGEMENT.N_LOGEMENT%TYPE as IDL SAE_LOGEMENT.N_LOGEMENT%TYPE;
begin 
    select SAE_LOGEMENT.N_LOGEMENT into IDL
    from SAE_LOGEMENT , SAE_CONTRAT_BAIL , sae_batiment
    where SAE_CONTRAT_BAIL.n_logement = SAE_LOGEMENT.n_logement
    and SAE_CONTRAT_BAIL.n_batiment = SAE_LOGEMENT.n_batiment
    and date_a > sae_contrat_bail.date_fin
    and sae_batiment.n_batiment = batiment_b;
    return IDL;
end  Logement_inhabitées ;


-- fonction existe entreprise
create or replace function existe_entreprise(PN_siren char ) return number is
nb number;
begin
    select count(*) into nb
    from sae_entreprise 
    where n_siren = PN_siren;
        if (nb <> 0) then
            return 1;
        else
            return 0;
        end if;
end;

-- fonction si le locataire existe 
create or replace function islocataireExist (idlocataire SAE_LOCATAIRE.id_locataire%type, phonenumber SAE_LOCATAIRE.TÉL%type) return number is
nb number;
BEGIN
    select count(*)into nb
    from sae_locataire
    where id_locataire=idlocataire
    AND tél=phonenumber;
        if(nb<>0)then
            return 1;
        else
            return 0;
        end if;
END;

-- afficher les infos d'un locataire 
create or replace function GET_LOCATAIRE(l_prenom sae_locataire.prenom%type ,l_nom sae_locataire.nom%type) return sys_refcursor as
curLoc sys_refcursor ;
begin
open curLoc for select *
from SAE_LOCATAIRE
where Nom = l_nom and prenom = l_prenom;
return curLoc ;
end GET_LOCATAIRE ;


-- afficher les infos d'un logement
create or replace function GET_LOGEMENT(numBat sae_logement.n_logement%type, numLog sae_logement.n_batiment%type) return sys_refcursor as curLog sys_refcursor;
begin
open curLog for select *
from sae_logement
where n_logement = numLog and n_batiment = numBat;
return curLog;
end GET_LOGEMENT;


-- afficher les infos de la facture

create or replace function GET_FACTURE(réf sae_facture.référence%type) return sys_refcursor as curFac sys_refcursor;
begin
open curFac for select *
from sae_facture f, sae_batiment b, sae_logement l
where f.référence = b.n_batiment and b.n_batiment = l.n_logement and f.référence = réf;
return curFac;
end GET_FACTURE;

-- retourne le bail d'un logement
create or replace FUNCTION GET_BAIL_LOGEMENT(nbLogement  number, nbBatiment  number)
    RETURN SYS_REFCURSOR
IS
    l_cur    	SYS_REFCURSOR;
    l_sql    	VARCHAR2 (32767);
BEGIN
 
	l_sql := 'Select id_bail, date_début, date_fin, frais_d_agence , Caution, nb_locataire
From SAE_Contrat_bail
where  SAE_Contrat_bail.n_logement =  ' ||  nbLogement|| '
And  SAE_Contrat_bail.n_batiment =  '  ||  nbBatiment || '
ORDER by 2 desc, 3 desc';
 
 
    OPEN l_cur FOR l_sql;
    RETURN l_cur;
END;

-- retourne l'état des lieux d'un logement
create or replace FUNCTION GET_EDL_LOGEMENT(nbLogement  number, nbBatiment  number)
    RETURN SYS_REFCURSOR
IS
    l_cur    	SYS_REFCURSOR;
    l_sql    	VARCHAR2 (32767);
BEGIN
 
	l_sql := ' Select SAE_Logement.réf_EDL, SAE_Logement.n_logement as number logement, SAE_Logement.porte, SAE_Logement.étage, SAE_Logement.n_batiment as number batiment, SAE_Logement.localisation, SAE_Logement.type
From SAE_Logement
where  SAE_Logement.n_logement = ' ||  nbLogement|| '
And  SAE_Logement.n_batiment = ' ||  nbBatiment;
 
 
	OPEN l_cur FOR l_sql;
    RETURN l_cur;
END;

-- retourne l'équipement d'un logement 
create or replace FUNCTION GET_EQUIPEMENT_LOGEMENT(nbLogement  number, nbBatiment  number)
    RETURN SYS_REFCURSOR
IS
    l_cur    	SYS_REFCURSOR;
    l_sql    	VARCHAR2 (32767);
BEGIN
 
	l_sql := ' Select SAE_Equipement.id_equipement as id , SAE_Equipement.nom as nom equipement, SAE_Equipement.date_de_validité_révision as date de validité révision, SAE_Equipement.date_dernière_révision as date dernière révision
From Posséder, SAE_Equipement
where  SAE_Posseder.n_logement =  ' ||  nbLogement|| '
And  SAE_Posseder.n_batiment = ' ||  nbBatiment || '
And SAE_Posseder.id_equipement = SAE_Equipement.id_equipement';
 
 
    OPEN l_cur FOR l_sql;
    RETURN l_cur;
END;

-- retourne le loyer d'un logement
create or replace FUNCTION GET_LOGEMENT_LOYER(nbLogement  number, nbBatiment  number)
    RETURN SYS_REFCURSOR
IS
    l_cur    	SYS_REFCURSOR;
    l_sql    	VARCHAR2 (32767);
BEGIN
 
	l_sql := 'Select SAE_Logement.n_logement as number logement, SAE_Logement.porte, SAE_Logement.étage, n_batiment as number batiment, SAE_Logement.localisation, (((SAE_Logement.Base_loyer_M * SAE_Logement.surface)* SAE_Logement.ICC )+  SAE_Logement.charges_fixes) as loyer
    From SAE_Logement
    where  SAE_Logement.n_logement = ' ||  nbLogement|| '
    And  SAE_Logement.n_batiment =  ' ||  nbBatiment ;
 
 
	OPEN l_cur FOR l_sql;
    RETURN l_cur;
END;

-- retourne la fiche de dignostic d'un logement
create or replace FUNCTION GET_DIAGNOSTIC_LOGEMENT(nbLogement  number, nbBatiment  number)
    RETURN SYS_REFCURSOR
IS
    l_cur    	SYS_REFCURSOR;
    l_sql    	VARCHAR2 (32767);
BEGIN
 
	l_sql := 'Select Réf, Amiante, Date_Amiante, Plomb, Date_plomb, date_diag_ERP, Date_ERP_de_validité, Date_limite_validité_DPE, Date_diag_DPE
From SAE_Fiche_diagnostic
Where  SAE_Fiche_diagnostic.n_logement =  ' ||  nbLogement|| '
And  SAE_Fiche_diagnostic.n_batiment = ' ||  nbBatiment;
 
 
    OPEN l_cur FOR l_sql;
    RETURN l_cur;
END;

-- retourne le bail d'un locataire
create or replace function GET_BAILLOC(l_nom sae_locataire.nom%type,l_prenom sae_locataire.prenom%type) return sys_refcursor as
curBail sys_refcursor ;
begin
open curBail for select CB.*
from SAE_CONTRAT_BAIL  CB,SAE_LOCATAIRE L, SAE_SIGNER S
where L.id_locataire = S.id_locataire
AND CB.id_bail = S.id_bail
AND Nom = l_nom and prenom = l_prenom;
return curBail ;
end GET_BAILLOC ;

-- retourne le bail d'un locataire
create or replace function GET_BAILLOC(l_nom sae_locataire.nom%type,l_prenom sae_locataire.prenom%type) return sys_refcursor as
    curBail sys_refcursor ;
begin
    open curBail for select SAE_CONTRAT_BAIL.*
    from SAE_CONTRAT_BAIL, SAE_LOCATAIRE, SAE_SIGNER
    where SAE_LOCATAIRE.id_locataire = SAE_SIGNER.id_locataire
    AND SAE_CONTRAT_BAIL.id_bail = SAE_SIGNER.id_bail
    AND lower(SAE_LOCATAIRE.Nom) = lower(l_nom) and lower(SAE_LOCATAIRE.prenom) = lower(l_prenom);
return curBail ;
end GET_BAILLOC ;

/ 
create or replace FUNCTION GET_TRAVAUX_LOGEMENT(nbLogement  number, nbBatiment  number)
	RETURN SYS_REFCURSOR
IS
	l_cur    	SYS_REFCURSOR;
	l_sql    	VARCHAR2 (32767);
BEGIN
	l_sql := 'Select SAE_Facture.référence,
	SAE_Facture.date_facture,
	SAE_Facture.Prix,
	SAE_Facture.référence_du_paiement,
	SAE_Facture.Date_de_paiement,
	SAE_Facture.type_de_paiement,
	SAE_Facture.n_SIREN ,
	SAE_Entreprise.Nom,
	(SAE_Entreprise.Adresse || ' || ''' , ''' || ' || SAE_Entreprise.CP) as Adresse,
	SAE_Entreprise.adresse_mail,
	SAE_Entreprise.Tél
	From SAE_lier_logement, SAE_Facture, SAE_Entreprise
	Where SAE_Facture.Id_Type_facture = 2
	And SAE_lier_logement.référence = SAE_Facture.référence
	And  SAE_lier_logement.n_batiment =  ' ||  nbBatiment || '
	And SAE_lier_logement.n_logement =  ' ||  nbLogement|| '
	And  SAE_Entreprise.n_SIREN = SAE_Facture.n_SIREN';
    
	OPEN l_cur FOR l_sql;
	RETURN l_cur;
END;



-- travaux faits et par quel entreprise
create or replace FUNCTION TRAVAUX_ENTREPRISE(PN_siren char ) return sys_refcursor as Liste_travaux sys_refcursor;
BEGIN
    if existe_entreprise(PN_siren) = 1 then 
        open Liste_travaux for select sae_facture.*
        from sae_facture
        where sae_facture.n_siren = PN_siren 
        and sae_facture.ID_TYPE_FACTURE =  '2';
        return Liste_travaux;
    else 
        raise_application_error(-20754 , 'Entreprise inexistante');
    end if;
END TRAVAUX_ENTREPRISE;


-- charges d'un logement
create or replace FUNCTION GET_CHARGES_LOGEMENT(nbLogement  number, nbBatiment  number)
	RETURN SYS_REFCURSOR
IS
	l_cur    	SYS_REFCURSOR;
	l_sql    	VARCHAR2 (32767);
BEGIN
 
	l_sql := 'Select SAE_type_charges.typeC, ( to_char(SAE_Charges.consommation) || ' || ''' ''' ||' ||SAE_Charges.unité) as consommation, SAE_Charges.Prix_unitaire, (to_char(SAE_Charges.consommation  * SAE_Charges.Prix_unitaire) || ' || '''  €''' ||' ) as prix_total,  SAE_Charges.Abonnement, SAE_Charges.Date_charges
        	From SAE_associer, SAE_Charges, SAE_type_charges
        	Where  SAE_associer.n_logement =  ' ||  nbLogement|| '
        	And  SAE_associer.n_batiment =   ' ||  nbBatiment || '
        	And SAE_associer.réf = SAE_Charges.réf 
            AND SAE_Charges.id_type_charges = SAE_type_charges.id_type_charges';
 
    
	OPEN l_cur FOR l_sql;
	RETURN l_cur;
END;

-- facture d'un batiment
create or replace FUNCTION GET_FACTURE_BATIMENT(nbBatiment  number)
	RETURN SYS_REFCURSOR
IS
	l_cur    	SYS_REFCURSOR;
	l_sql    	VARCHAR2 (32767);
BEGIN
    l_sql :='Select SAE_Facture.référence,
	SAE_Facture.date_facture,
	(to_char(SAE_Charges.consommation  * SAE_Charges.Prix_unitaire) || ' || '''  €''' ||' ) as prix_total,
    SAE_Facture.description,
	SAE_Facture.référence_du_paiement,
	SAE_Facture.Date_de_paiement,
	SAE_Facture.type_de_paiement,
    FROM SAE_facture, SAE_lier_logement, SAE_Charges
    WHERE SAE_lier_logement.référence = SAE_Facture
    And  SAE_lier_logement.n_batiment =  ' ||  nbBatiment || '
    AND SAE_Facture.id_type_facture = 1';
OPEN l_cur FOR l_sql;
	RETURN l_cur;
END;

-- facture d'un locataire
create or replace FUNCTION GET_FACTURE_LOCATAIRE(l_nom varchar2, l_prenom varchar2)
    RETURN SYS_REFCURSOR
IS
    l_cur        SYS_REFCURSOR;
BEGIN
    OPEN l_cur FOR Select SAE_Facture.référence,
    SAE_Facture.date_facture,
    SAE_Facture.Prix,
    SAE_Facture.référence_du_paiement,
    SAE_Facture.Date_de_paiement,
    SAE_Facture.type_de_paiement
    From SAE_lier_logement, SAE_Facture, SAE_Entreprise, SAE_Logement, SAE_CONTRAT_BAIL,SAE_LOCATAIRE, SAE_SIGNER
    Where SAE_Facture.Id_Type_facture = 1
    And SAE_lier_logement.référence = SAE_Facture.référence
    And  SAE_lier_logement.n_batiment =  SAE_Logement.n_batiment 
    And SAE_lier_logement.n_logement =  SAE_Logement.n_logement
    And SAE_CONTRAT_BAIL.n_batiment =  SAE_Logement.n_batiment 
    And SAE_CONTRAT_BAIL.n_logement =  SAE_Logement.n_logement
    And SAE_SIGNER.id_bail = SAE_CONTRAT_BAIL.id_bail
    And SAE_LOCATAIRE.id_locataire = SAE_SIGNER.id_locataire
    And lower(SAE_LOCATAIRE.Nom) = lower(l_nom) 
    And lower(SAE_LOCATAIRE.prenom) = lower(l_prenom);
    
    RETURN l_cur;
END GET_FACTURE_LOCATAIRE;

-- charges d'un locataire
create or replace FUNCTION GET_CHARGES_LOCATAIRE(l_nom varchar2, l_prenom varchar2)
    RETURN SYS_REFCURSOR
IS
    l_cur        SYS_REFCURSOR;
BEGIN
    OPEN l_cur FOR Select SAE_type_charges.typeC as type_charges, 
    ( to_char(SAE_Charges.consommation) || ' ' ||SAE_Charges.unité) as consommation, 
    (to_char(SAE_Charges.Prix_unitaire ) || ' €' ) as prix_total, 
    (to_char(SAE_Charges.consommation  * SAE_Charges.Prix_unitaire) || ' €' ) as prix_total, 
    (to_char(SAE_Charges.Abonnement) || ' j' ) as Abonnement,
    SAE_Charges.Date_charges
            From SAE_associer, SAE_Charges, SAE_type_charges, SAE_CONTRAT_BAIL,  SAE_Logement, SAE_SIGNER, SAE_LOCATAIRE
            Where SAE_Charges.id_type_charges = SAE_type_charges.id_type_charges
            And SAE_associer.réf = SAE_Charges.réf 
            And SAE_associer.n_logement =  SAE_Logement.n_logement 
            And SAE_associer.n_batiment   =  SAE_Logement.n_batiment 
            And SAE_CONTRAT_BAIL.n_batiment =  SAE_Logement.n_batiment 
            And SAE_CONTRAT_BAIL.n_logement =  SAE_Logement.n_logement
            And SAE_SIGNER.id_bail = SAE_CONTRAT_BAIL.id_bail
            And SAE_LOCATAIRE.id_locataire = SAE_SIGNER.id_locataire
            And lower(SAE_LOCATAIRE.Nom) = lower(l_nom) 
            And lower(SAE_LOCATAIRE.prenom) = lower(l_prenom);
    
    RETURN l_cur;
END GET_CHARGES_LOCATAIRE;


commit;
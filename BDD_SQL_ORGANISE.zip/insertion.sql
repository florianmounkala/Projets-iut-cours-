-- insertion des données locataires
 
insert into SAE_Locataire(id_locataire, nom, prenom, adresse_domicil_société, E_mail, Tél) values (0, 'Rébecca', 'Armand', '7 rue des Fleurs 75012 Paris', 'RebeccaArmand@gmail.com', '0695454332'); 
insert into SAE_Locataire(id_locataire, nom, prenom, adresse_domicil_société, E_mail, Tél) values (1, 'Pierre', 'Giraud', '9 avenue des boulevards 75014 Paris', 'PierreGiraud@gmail.com', '0693504332'); 
insert into SAE_Locataire(id_locataire, nom, prenom, adresse_domicil_société, E_mail, Tél) values (2, 'Mathilde', 'Mayet', '342 route de fosse 75011 Paris', 'MathildeMayet@gmail.com', '07657463') ;
insert into SAE_Locataire(id_locataire, nom, prenom, adresse_domicil_société, E_mail, Tél) values (3, 'Florian', 'Deschamps', '7 rue des Fleurs 75012 Paris', 'FlorianDeschamps@gmail.com', '0695342321') ;
insert into SAE_Locataire(id_locataire, nom, prenom, adresse_domicil_société, E_mail, Tél) values (4, 'Thomas', 'Bouisse', '343 route de fosse 75011 Paris', 'ThomasBouisse@gmail.com', '0798562412') 

-- insertion dans équipement 
insert into sae_equipement (id_equipement, date_dernière_révision, nom, date_de_validité_révision) values (0, '14/03/2015', 'Chaudière', '14/03/2025');

-- insertion des données batiment

insert into sae_batiment(n_batiment, nb_logement, code_postal, nb_étage, rue, ville) values (0, 20, '75012', '4', 'rue des Fleurs', 'Paris');
insert into sae_batiment(n_batiment, nb_logement, code_postal, nb_étage, rue, ville) values (1, 15, '75014', '3', 'avenue des boulevards', 'Paris');
insert into sae_batiment(n_batiment, nb_logement, code_postal, nb_étage, rue, ville) values (2, 25, '75011', '5', 'route de fosse', 'Paris');

-- insertion dans sae_type_charges
insert into sae_type_charges(id_type_charges, typec) values (0, 'Electricité');
insert into sae_type_charges(id_type_charges, typec) values (1, 'Gaz');
insert into sae_type_charges(id_type_charges, typec) values (2, 'Eau');

--insertion dans charges

insert into sae_charges(réf, consommation, unité, prix_unitaire, abonnement, date_charges, id_type_charges) values ('ELEC10001', 10, 'Kwh', 1.34, 30, '05/12/2022', 0);
insert into sae_charges(réf, consommation, unité, prix_unitaire, abonnement, date_charges, id_type_charges) values ('ELEC20001', 20, 'Kwh', 1.34, 40, '06/12/22', 0);
insert into sae_charges(réf, consommation, unité, prix_unitaire, abonnement, date_charges, id_type_charges) values ('EAU20001', 30, 'm3', 4.14, 70, '06/12/22', 2);
insert into sae_charges(réf, consommation, unité, prix_unitaire, abonnement, date_charges, id_type_charges) values ('GAZ10001', 50, 'm3', 2.20, 60, '07/12/22', 1);
insert into sae_charges(réf, consommation, unité, prix_unitaire, abonnement, date_charges, id_type_charges) values ('EAU10001', 50, 'm3', 4.14, 60, '07/12/22', 2);

-- insertion des données dans entreprise

insert into sae_entreprise(n_siren, nom, adresse, cp, iban, adresse_mail, tél)values (362521879, 'New Tech', '210 avenue de Rangueil', 75010, 'FR7630001007941234567890185', 'NewTech@gmail.com', 0598123445);
insert into sae_entreprise(n_siren, nom, adresse, cp, iban, adresse_mail, tél)values (243564567, 'Les charpentiers', 'Rue de la paix', 78012, 'FR7630004000031234567890143', 'LesCharpentiers@gmail.com', 0596043405);
insert into sae_entreprise(n_siren, nom, adresse, cp, iban, adresse_mail, tél)values (453123765, 'Entreprise travaux', 'Rue de la guerre', 77012, 'FR7630006000011234567890189', 'Travaux@gmail.com', 0598032345);
insert into sae_entreprise(n_siren, nom, adresse, cp, iban, adresse_mail, tél)values (343564567, 'Les travailleurs', 'Rue de la joie', 78012, 'FR7630004000031234567890143', 'LesTravailleurs@gmail.com', 0596041455);
insert into sae_entreprise(n_siren, nom, adresse, cp, iban, adresse_mail, tél)values (0, 'None', null, null, 0, null, null);

-- insertion dans type facture

insert into sae_type_facture(id_type_facture, typeF) values (1, 'Charges');
insert into sae_type_facture(id_type_facture, typeF) values (2, 'Travaux');
insert into sae_type_facture(id_type_facture, typeF) values (3, 'Fiscales');

-- insertion des données logement

insert into sae_logement(n_batiment, n_logement, localisation, typelogement, régime_juridique, balcon, période_de_construction, surface, nb_pièces, garage, jardin, étage, porte, réf_edl, base_loyer_m, charges_fixes, icc) values (0, 0, '7 rue des Fleurs 75012 Paris', 'appartement', 'Standard', 1, '12/02/2009', 40, 5, 0, 0, '1er étage', '7', 10102020, 14, 100, 1.3);
insert into sae_logement(n_batiment, n_logement, localisation, typelogement, régime_juridique, balcon, période_de_construction, surface, nb_pièces, garage, jardin, étage, porte, réf_edl, base_loyer_m, charges_fixes, icc) values (1, 1, '9 avenue des boulevards 75014 Paris', 'appartement', 'Standard', 1, '12/02/2011', 20, 3, 0, 0, '2ème étage', '9', 10103030, 14, 200, 1.3);
insert into sae_logement(n_batiment, n_logement, localisation, typelogement, régime_juridique, balcon, période_de_construction, surface, nb_pièces, garage, jardin, étage, porte, réf_edl, base_loyer_m, charges_fixes, icc) values (2, 2, '342 route de fosse 75011 Paris', 'appartement', 'Standard', 1, '12/02/2006', 60, 5, 0, 0, '5ème étage', '20', 10104040, 14, 200, 1.3);
insert into sae_logement(n_batiment, n_logement, localisation, typelogement, régime_juridique, balcon, période_de_construction, surface, nb_pièces, garage, jardin, étage, porte, réf_edl, base_loyer_m, charges_fixes, icc) values (0, 3, '7 rue des Fleurs 75012 Paris', 'appartement', 'Standard', 1, '12/02/2009', 50, 5, 0, 0, '3ème étage', '10', 10105050, 14, 150, 1.3);

-- insertion des données dans la facture

insert into sae_facture(référence, RÉFÉRENCE_DU_PAIEMENT, DATE_FACTURE, CHARGES_DUES, CHARGES_RÉGULARISÉS, DATE_DE_PAIEMENT, TYPE_DE_PAIEMENT, AIDE, MONTANT_DE_L_AIDE, PRIX, ID_TYPE_FACTURE, N_SIREN, description) values (0, '80KM0', '12/11/2022', 40, 0, '02/11/2022', 'Virement', 0, 0, 50, 1, 0, 'Quittance de Loyer');
insert into sae_facture(référence, RÉFÉRENCE_DU_PAIEMENT, DATE_FACTURE, CHARGES_DUES, CHARGES_RÉGULARISÉS, DATE_DE_PAIEMENT, TYPE_DE_PAIEMENT, AIDE, MONTANT_DE_L_AIDE, PRIX, ID_TYPE_FACTURE, N_SIREN, description) values (1, '615XJ', '13/11/2022', 50, 0, '02/11/2022', 'Virement', 0, 0, 60, 1, 0, 'Facture des eaux');
insert into sae_facture(référence, RÉFÉRENCE_DU_PAIEMENT, DATE_FACTURE, CHARGES_DUES, CHARGES_RÉGULARISÉS, DATE_DE_PAIEMENT, TYPE_DE_PAIEMENT, AIDE, MONTANT_DE_L_AIDE, PRIX, ID_TYPE_FACTURE, N_SIREN, description) values (2, 'Y4P75', '01/11/2022', 100, 0, '24/10/2022', 'Virement', 0, 0, 1000, 2, 243564567, 'Rénovation chauffage');

-- insertion dans fiche diagnostic

insert into sae_fiche_diagnostic(réf, amiante, date_amiante, plomb, date_plomb, date_diag_erp, date_erp_de_validité, DATE_LIMITE_VALIDITÉ_DPE, date_diag_dpe, n_batiment, n_logement) values (101010100, 0, '03/03/2018', 0, '28/09/2017', '14/02/2019', '10/02/2026', '19/12/2026', '19/12/2019', 0, 0);


-- insertion des données contrat_bail

insert into sae_contrat_bail(id_bail, date_début, date_fin, frais_d_agence, caution, nb_locataire, n_batiment, n_logement) values (0, '12/01/2022', '12/01/2024', '100', '400', '1', '1', '1');
insert into sae_contrat_bail(id_bail, date_début, date_fin, frais_d_agence, caution, nb_locataire, n_batiment, n_logement) values (1, '12/01/2022', '12/07/2022', '200', '300', '1', '2', '2');



-- insertion dans sae_associer
insert into sae_associer (n_batiment, n_logement, réf) values (0, 0, 'ELEC10001'); 
insert into sae_associer (n_batiment, n_logement, réf) values (0, 3, 'ELEC10001'); 
insert into sae_associer (n_batiment, n_logement, réf) values (0, 3, 'EAU10001'); 
insert into sae_associer (n_batiment, n_logement, réf) values (0, 3, 'GAZ10001');

-- insertion dans sae_lier_logement
insert into sae_lier_logement (référence, n_batiment, n_logement) values (0, 0, 0);
insert into sae_lier_logement (référence, n_batiment, n_logement) values (1, 1, 1);
insert into sae_lier_logement (référence, n_batiment, n_logement) values (2, 0, 3);

-- insertion dans sae_signer
insert into sae_signer(id_bail, id_locataire) values (0, 4);

-- insertion dans sae_posseder
insert into sae_posseder(id_equipement, n_batiment, n_logement) values (0, 0, 0);